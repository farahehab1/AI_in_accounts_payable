
  # Procurement and Invoice Automation

  This is a code bundle for Procurement and Invoice Automation. The original project is available at https://www.figma.com/design/UIv2N5a1blew8YZLS6PaUT/Procurement-and-Invoice-Automation.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  