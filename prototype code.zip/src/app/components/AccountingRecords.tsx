import { useState } from "react";
import { BookOpen, CheckCircle, Activity, TrendingUp, Database, RefreshCw } from "lucide-react";

interface AccountingEntry {
  id: string;
  paymentId: string;
  transactionDate: string;
  supplier: string;
  amount: string;
  category: string;
  accountsAffected: {
    debit: { account: string; amount: string };
    credit: { account: string; amount: string };
  }[];
  updateStatus: "completed" | "processing" | "pending";
  automationDetails: {
    triggeredBy: string;
    processingTime: string;
    relatedDocuments: string[];
    reconciliationStatus: string;
  };
}

export function AccountingRecords() {
  const [selectedEntry, setSelectedEntry] = useState<AccountingEntry | null>(null);

  const entries: AccountingEntry[] = [
    {
      id: "AR-001",
      paymentId: "PAY-001",
      transactionDate: "2026-04-20 15:45",
      supplier: "Office Depot Inc.",
      amount: "$1,245.00",
      category: "Office Supplies",
      accountsAffected: [
        {
          debit: { account: "Office Supplies Expense (5100)", amount: "$1,200.00" },
          credit: { account: "Cash - Operating Account (1010)", amount: "$1,200.00" }
        },
        {
          debit: { account: "Input Tax (1500)", amount: "$45.00" },
          credit: { account: "Cash - Operating Account (1010)", amount: "$45.00" }
        }
      ],
      updateStatus: "completed",
      automationDetails: {
        triggeredBy: "Payment completion confirmed by bank",
        processingTime: "2.3 seconds",
        relatedDocuments: ["PO-0315", "INV-001", "GR-0287", "BV-001"],
        reconciliationStatus: "Fully reconciled"
      }
    },
    {
      id: "AR-002",
      paymentId: "PAY-003",
      transactionDate: "2026-04-21 11:30",
      supplier: "Industrial Supply Co.",
      amount: "$3,850.00",
      category: "Maintenance Supplies",
      accountsAffected: [
        {
          debit: { account: "Maintenance Expense (5200)", amount: "$3,700.00" },
          credit: { account: "Cash - Operating Account (1010)", amount: "$3,700.00" }
        },
        {
          debit: { account: "Input Tax (1500)", amount: "$150.00" },
          credit: { account: "Cash - Operating Account (1010)", amount: "$150.00" }
        }
      ],
      updateStatus: "completed",
      automationDetails: {
        triggeredBy: "Payment completion confirmed by bank",
        processingTime: "1.8 seconds",
        relatedDocuments: ["PO-0317", "INV-002", "GR-0289", "BV-002"],
        reconciliationStatus: "Fully reconciled"
      }
    },
    {
      id: "AR-003",
      paymentId: "PAY-004",
      transactionDate: "2026-04-22 09:45",
      supplier: "PrintPro Solutions",
      amount: "$2,100.00",
      category: "Marketing Expense",
      accountsAffected: [
        {
          debit: { account: "Marketing Expense (6100)", amount: "$2,000.00" },
          credit: { account: "Cash - Operating Account (1010)", amount: "$2,000.00" }
        },
        {
          debit: { account: "Input Tax (1500)", amount: "$100.00" },
          credit: { account: "Cash - Operating Account (1010)", amount: "$100.00" }
        }
      ],
      updateStatus: "processing",
      automationDetails: {
        triggeredBy: "Payment processing in progress",
        processingTime: "Processing...",
        relatedDocuments: ["PO-0318", "INV-004", "BV-003"],
        reconciliationStatus: "Pending bank confirmation"
      }
    },
    {
      id: "AR-004",
      paymentId: "PAY-002",
      transactionDate: "2026-04-19 14:45",
      supplier: "Dell Technologies",
      amount: "$12,475.00",
      category: "IT Equipment",
      accountsAffected: [
        {
          debit: { account: "Computer Equipment (1400)", amount: "$12,000.00" },
          credit: { account: "Accounts Payable (2100)", amount: "$12,000.00" }
        },
        {
          debit: { account: "Input Tax (1500)", amount: "$475.00" },
          credit: { account: "Accounts Payable (2100)", amount: "$475.00" }
        }
      ],
      updateStatus: "pending",
      automationDetails: {
        triggeredBy: "Awaiting payment retry after bank failure",
        processingTime: "On hold",
        relatedDocuments: ["PO-0316", "INV-003", "GR-0290", "BV-005"],
        reconciliationStatus: "Payment failed - On hold"
      }
    }
  ];

  const getStatusBadge = (status: AccountingEntry["updateStatus"]) => {
    const badges = {
      completed: { label: "Updated", color: "bg-green-100 text-green-800", icon: CheckCircle },
      processing: { label: "Processing", color: "bg-blue-100 text-blue-800", icon: RefreshCw },
      pending: { label: "Pending", color: "bg-yellow-100 text-yellow-800", icon: Activity }
    };
    return badges[status];
  };

  const completedCount = entries.filter(e => e.updateStatus === 'completed').length;
  const totalAmount = entries.reduce((sum, e) => sum + parseFloat(e.amount.replace(/[$,]/g, '')), 0);
  const processingCount = entries.filter(e => e.updateStatus === 'processing').length;
  const avgProcessingTime = 2.05;

  return (
    <div className="p-8">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-slate-900">Accounting Records</h1>
        <p className="text-slate-600 mt-2">Automatic financial record updates for accurate accounting</p>
      </div>

      {/* Feature Card */}
      

      {/* Statistics */}
      

      {/* Benefits Section */}
      

      {/* Accounting Entries List */}
      <div className="bg-white rounded-lg shadow">
        <div className="p-6 border-b border-slate-200">
          <h2 className="text-xl font-bold text-slate-900">Recent Accounting Entries</h2>
        </div>

        <div className="divide-y divide-slate-200">
          {entries.map((entry) => {
            const statusBadge = getStatusBadge(entry.updateStatus);
            const StatusIcon = statusBadge.icon;

            return (
              <div
                key={entry.id}
                className="p-6 hover:bg-slate-50 cursor-pointer transition-colors"
                onClick={() => setSelectedEntry(entry)}
              >
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-3">
                      <h3 className="font-bold text-slate-900">{entry.id}</h3>
                      <span className={`px-3 py-1 rounded-full text-xs font-medium ${statusBadge.color} flex items-center gap-1`}>
                        <StatusIcon size={12} className={entry.updateStatus === 'processing' ? 'animate-spin' : ''} />
                        {statusBadge.label}
                      </span>
                      <span className="px-3 py-1 rounded-full text-xs font-medium bg-slate-100 text-slate-700">
                        {entry.category}
                      </span>
                    </div>

                    <div className="grid grid-cols-3 gap-4 mb-3">
                      <div>
                        <p className="text-xs text-slate-500">Payment ID</p>
                        <p className="text-sm font-medium text-slate-900">{entry.paymentId}</p>
                      </div>
                      <div>
                        <p className="text-xs text-slate-500">Supplier</p>
                        <p className="text-sm font-medium text-slate-900">{entry.supplier}</p>
                      </div>
                      <div>
                        <p className="text-xs text-slate-500">Transaction Date</p>
                        <p className="text-sm font-medium text-slate-900">{entry.transactionDate}</p>
                      </div>
                    </div>

                    <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                      <div className="flex items-start gap-2 mb-3">
                        <BookOpen className="text-blue-600 mt-0.5" size={16} />
                        <div className="flex-1">
                          <p className="text-sm font-medium text-blue-900">ARU-1: Automatic Financial Record Update</p>
                          <p className="text-xs text-blue-700 mt-1">{entry.automationDetails.triggeredBy}</p>
                        </div>
                      </div>

                      <div className="space-y-2">
                        {entry.accountsAffected.map((account, idx) => (
                          <div key={idx} className="bg-white rounded p-3">
                            <div className="grid grid-cols-2 gap-4 text-xs">
                              <div>
                                <p className="text-slate-500 mb-1">Debit</p>
                                <p className="font-medium text-slate-900">{account.debit.account}</p>
                                <p className="text-sm font-bold text-green-600">{account.debit.amount}</p>
                              </div>
                              <div>
                                <p className="text-slate-500 mb-1">Credit</p>
                                <p className="font-medium text-slate-900">{account.credit.account}</p>
                                <p className="text-sm font-bold text-red-600">{account.credit.amount}</p>
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>

                      <div className="mt-3 pt-3 border-t border-blue-200 grid grid-cols-3 gap-3 text-xs">
                        <div>
                          <p className="text-blue-700">Processing Time</p>
                          <p className="font-medium text-blue-900">{entry.automationDetails.processingTime}</p>
                        </div>
                        <div>
                          <p className="text-blue-700">Reconciliation</p>
                          <p className="font-medium text-blue-900">{entry.automationDetails.reconciliationStatus}</p>
                        </div>
                        <div>
                          <p className="text-blue-700">Related Docs</p>
                          <p className="font-medium text-blue-900">{entry.automationDetails.relatedDocuments.length} linked</p>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="text-right ml-4">
                    <div className="text-2xl font-bold text-slate-900">{entry.amount}</div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Selected Entry Details Modal */}
      {selectedEntry && (
        <div
          className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-8"
          onClick={() => setSelectedEntry(null)}
        >
          <div
            className="bg-white rounded-lg shadow-xl max-w-4xl w-full max-h-[90vh] overflow-auto"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="p-6 border-b border-slate-200">
              <h2 className="text-2xl font-bold text-slate-900">Accounting Entry: {selectedEntry.id}</h2>
            </div>

            <div className="p-6 space-y-6">
              {/* Entry Overview */}
              <div className="bg-slate-50 rounded-lg p-4">
                <h3 className="font-semibold text-slate-900 mb-3">Transaction Overview</h3>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-xs text-slate-500 mb-1">Payment ID</p>
                    <p className="font-medium text-slate-900">{selectedEntry.paymentId}</p>
                  </div>
                  <div>
                    <p className="text-xs text-slate-500 mb-1">Category</p>
                    <p className="font-medium text-slate-900">{selectedEntry.category}</p>
                  </div>
                  <div>
                    <p className="text-xs text-slate-500 mb-1">Supplier</p>
                    <p className="font-medium text-slate-900">{selectedEntry.supplier}</p>
                  </div>
                  <div>
                    <p className="text-xs text-slate-500 mb-1">Amount</p>
                    <p className="text-2xl font-bold text-slate-900">{selectedEntry.amount}</p>
                  </div>
                  <div>
                    <p className="text-xs text-slate-500 mb-1">Transaction Date</p>
                    <p className="font-medium text-slate-900">{selectedEntry.transactionDate}</p>
                  </div>
                  <div>
                    <p className="text-xs text-slate-500 mb-1">Update Status</p>
                    <span className={`inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-medium ${getStatusBadge(selectedEntry.updateStatus).color}`}>
                      {selectedEntry.updateStatus === 'completed' && <CheckCircle size={12} />}
                      {selectedEntry.updateStatus === 'processing' && <RefreshCw size={12} className="animate-spin" />}
                      {selectedEntry.updateStatus === 'pending' && <Activity size={12} />}
                      {getStatusBadge(selectedEntry.updateStatus).label}
                    </span>
                  </div>
                </div>
              </div>

              {/* ARU-1: Automatic Updates */}
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                <div className="flex items-start gap-3">
                  <BookOpen className="text-blue-600 mt-1" size={24} />
                  <div className="flex-1">
                    <h3 className="font-semibold text-blue-900 mb-3">ARU-1: Automatic Financial Record Update</h3>

                    <div className="bg-white rounded-lg p-4 mb-4">
                      <h4 className="font-medium text-slate-900 mb-3">Journal Entries</h4>
                      <div className="space-y-4">
                        {selectedEntry.accountsAffected.map((account, idx) => (
                          <div key={idx} className="border border-slate-200 rounded-lg p-4">
                            <p className="text-xs text-slate-500 mb-3">Entry {idx + 1}</p>
                            <div className="grid grid-cols-2 gap-6">
                              <div>
                                <div className="flex items-center gap-2 mb-2">
                                  <div className="w-3 h-3 rounded-full bg-green-600"></div>
                                  <span className="text-sm font-medium text-slate-900">Debit</span>
                                </div>
                                <div className="pl-5">
                                  <p className="text-sm font-medium text-slate-900">{account.debit.account}</p>
                                  <p className="text-xl font-bold text-green-600 mt-1">{account.debit.amount}</p>
                                </div>
                              </div>
                              <div>
                                <div className="flex items-center gap-2 mb-2">
                                  <div className="w-3 h-3 rounded-full bg-red-600"></div>
                                  <span className="text-sm font-medium text-slate-900">Credit</span>
                                </div>
                                <div className="pl-5">
                                  <p className="text-sm font-medium text-slate-900">{account.credit.account}</p>
                                  <p className="text-xl font-bold text-red-600 mt-1">{account.credit.amount}</p>
                                </div>
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>

                    <div className="bg-white rounded-lg p-4">
                      <h4 className="font-medium text-slate-900 mb-3">Automation Details</h4>
                      <div className="space-y-3">
                        <div className="flex items-start gap-3">
                          <CheckCircle className="text-green-600 mt-0.5" size={16} />
                          <div className="flex-1">
                            <p className="text-sm font-medium text-slate-900">Trigger Event</p>
                            <p className="text-sm text-slate-700">{selectedEntry.automationDetails.triggeredBy}</p>
                          </div>
                        </div>
                        <div className="flex items-start gap-3">
                          <CheckCircle className="text-green-600 mt-0.5" size={16} />
                          <div className="flex-1">
                            <p className="text-sm font-medium text-slate-900">Processing Performance</p>
                            <p className="text-sm text-slate-700">Record updated in {selectedEntry.automationDetails.processingTime}</p>
                          </div>
                        </div>
                        <div className="flex items-start gap-3">
                          <CheckCircle className="text-green-600 mt-0.5" size={16} />
                          <div className="flex-1">
                            <p className="text-sm font-medium text-slate-900">Reconciliation Status</p>
                            <p className="text-sm text-slate-700">{selectedEntry.automationDetails.reconciliationStatus}</p>
                          </div>
                        </div>
                        <div className="flex items-start gap-3">
                          <CheckCircle className="text-green-600 mt-0.5" size={16} />
                          <div className="flex-1">
                            <p className="text-sm font-medium text-slate-900">Related Documents</p>
                            <div className="flex flex-wrap gap-2 mt-2">
                              {selectedEntry.automationDetails.relatedDocuments.map((doc, idx) => (
                                <span key={idx} className="px-2 py-1 bg-blue-100 text-blue-800 text-xs rounded">
                                  {doc}
                                </span>
                              ))}
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>

                    <p className="text-xs text-blue-600 mt-3">
                      AI automatically creates journal entries, updates general ledger, reconciles accounts, and maintains audit trail - all in real-time after payment confirmation
                    </p>
                  </div>
                </div>
              </div>

              {/* Automation Timeline */}
              <div className="bg-slate-50 border border-slate-200 rounded-lg p-4">
                <h3 className="font-semibold text-slate-900 mb-3">Automation Timeline</h3>
                <div className="space-y-3">
                  <div className="flex items-start gap-3">
                    <div className="w-8 h-8 rounded-full bg-blue-600 flex items-center justify-center text-white text-xs font-bold">1</div>
                    <div>
                      <p className="text-sm font-medium text-slate-900">Payment Completed</p>
                      <p className="text-xs text-slate-600">Bank verification confirmed successful payment</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <div className="w-8 h-8 rounded-full bg-blue-600 flex items-center justify-center text-white text-xs font-bold">2</div>
                    <div>
                      <p className="text-sm font-medium text-slate-900">AI Trigger Activated</p>
                      <p className="text-xs text-slate-600">Automatic record update initiated</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <div className="w-8 h-8 rounded-full bg-blue-600 flex items-center justify-center text-white text-xs font-bold">3</div>
                    <div>
                      <p className="text-sm font-medium text-slate-900">Journal Entries Created</p>
                      <p className="text-xs text-slate-600">Debit and credit entries automatically generated</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <div className="w-8 h-8 rounded-full bg-blue-600 flex items-center justify-center text-white text-xs font-bold">4</div>
                    <div>
                      <p className="text-sm font-medium text-slate-900">General Ledger Updated</p>
                      <p className="text-xs text-slate-600">All affected accounts automatically adjusted</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <div className="w-8 h-8 rounded-full bg-green-600 flex items-center justify-center text-white text-xs font-bold">✓</div>
                    <div>
                      <p className="text-sm font-medium text-green-900">Reconciliation Complete</p>
                      <p className="text-xs text-green-700">Records accurate and up-to-date</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="p-6 border-t border-slate-200 flex justify-end">
              <button
                onClick={() => setSelectedEntry(null)}
                className="px-6 py-2 bg-slate-900 text-white rounded-lg hover:bg-slate-800 transition-colors"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
