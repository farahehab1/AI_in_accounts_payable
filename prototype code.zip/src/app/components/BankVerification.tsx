import { useState } from "react";
import { Building2, CheckCircle, XCircle, Clock, RefreshCw, AlertTriangle, Activity } from "lucide-react";

interface BankTransaction {
  id: string;
  paymentId: string;
  supplier: string;
  amount: string;
  initiatedDate: string;
  bankStatus: "completed" | "pending" | "failed" | "processing";
  verificationStatus: "verified" | "verifying" | "error" | "not_verified";
  bankReference: string;
  lastChecked: string;
  retryCount: number;
  errorMessage?: string;
  verificationDetails: {
    bankName: string;
    accountNumber: string;
    transactionType: string;
    processingTime: string;
  };
}

export function BankVerification() {
  const [selectedTransaction, setSelectedTransaction] = useState<BankTransaction | null>(null);
  const [statusFilter, setStatusFilter] = useState<"all" | BankTransaction["bankStatus"]>("all");

  const transactions: BankTransaction[] = [
    {
      id: "BV-001",
      paymentId: "PAY-001",
      supplier: "Office Depot Inc.",
      amount: "$1,245.00",
      initiatedDate: "2026-04-20 14:30",
      bankStatus: "completed",
      verificationStatus: "verified",
      bankReference: "BNK-REF-78945612",
      lastChecked: "2026-04-20 15:45",
      retryCount: 0,
      verificationDetails: {
        bankName: "Chase Business Bank",
        accountNumber: "****5678",
        transactionType: "ACH Transfer",
        processingTime: "1h 15m"
      }
    },
    {
      id: "BV-002",
      paymentId: "PAY-003",
      supplier: "Industrial Supply Co.",
      amount: "$3,850.00",
      initiatedDate: "2026-04-21 09:15",
      bankStatus: "completed",
      verificationStatus: "verified",
      bankReference: "BNK-REF-78945613",
      lastChecked: "2026-04-21 11:30",
      retryCount: 0,
      verificationDetails: {
        bankName: "Chase Business Bank",
        accountNumber: "****5678",
        transactionType: "Wire Transfer",
        processingTime: "2h 15m"
      }
    },
    {
      id: "BV-003",
      paymentId: "PAY-004",
      supplier: "PrintPro Solutions",
      amount: "$2,100.00",
      initiatedDate: "2026-04-21 16:45",
      bankStatus: "processing",
      verificationStatus: "verifying",
      bankReference: "BNK-REF-78945614",
      lastChecked: "2026-04-22 09:30",
      retryCount: 2,
      verificationDetails: {
        bankName: "Chase Business Bank",
        accountNumber: "****5678",
        transactionType: "ACH Transfer",
        processingTime: "In progress"
      }
    },
    {
      id: "BV-004",
      paymentId: "PAY-005",
      supplier: "Microsoft Corporation",
      amount: "$7,500.00",
      initiatedDate: "2026-04-22 08:00",
      bankStatus: "pending",
      verificationStatus: "not_verified",
      bankReference: "BNK-REF-78945615",
      lastChecked: "2026-04-22 10:00",
      retryCount: 0,
      verificationDetails: {
        bankName: "Chase Business Bank",
        accountNumber: "****5678",
        transactionType: "Wire Transfer",
        processingTime: "Pending"
      }
    },
    {
      id: "BV-005",
      paymentId: "PAY-002",
      supplier: "Dell Technologies",
      amount: "$12,475.00",
      initiatedDate: "2026-04-19 11:20",
      bankStatus: "failed",
      verificationStatus: "error",
      bankReference: "BNK-REF-78945611",
      lastChecked: "2026-04-19 14:30",
      retryCount: 3,
      errorMessage: "Insufficient funds in account - Payment returned by bank",
      verificationDetails: {
        bankName: "Chase Business Bank",
        accountNumber: "****5678",
        transactionType: "Wire Transfer",
        processingTime: "Failed after 3h 10m"
      }
    }
  ];

  const filteredTransactions = transactions.filter((t) => {
    if (statusFilter === "all") return true;
    return t.bankStatus === statusFilter;
  });

  const getBankStatusBadge = (status: BankTransaction["bankStatus"]) => {
    const badges = {
      completed: { label: "Completed", color: "bg-green-100 text-green-800", icon: CheckCircle },
      pending: { label: "Pending", color: "bg-yellow-100 text-yellow-800", icon: Clock },
      failed: { label: "Failed", color: "bg-red-100 text-red-800", icon: XCircle },
      processing: { label: "Processing", color: "bg-blue-100 text-blue-800", icon: RefreshCw }
    };
    return badges[status];
  };

  const getVerificationBadge = (status: BankTransaction["verificationStatus"]) => {
    const badges = {
      verified: { label: "Verified", color: "bg-green-100 text-green-800", icon: CheckCircle },
      verifying: { label: "Verifying", color: "bg-blue-100 text-blue-800", icon: RefreshCw },
      error: { label: "Error", color: "bg-red-100 text-red-800", icon: XCircle },
      not_verified: { label: "Not Verified", color: "bg-slate-100 text-slate-800", icon: Clock }
    };
    return badges[status];
  };

  const completedCount = transactions.filter(t => t.bankStatus === 'completed').length;
  const failedCount = transactions.filter(t => t.bankStatus === 'failed').length;
  const pendingCount = transactions.filter(t => t.bankStatus === 'pending' || t.bankStatus === 'processing').length;
  const totalAmount = transactions.reduce((sum, t) => sum + parseFloat(t.amount.replace(/[$,]/g, '')), 0);

  return (
    <div className="p-8">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-slate-900">Bank Verification</h1>
        <p className="text-slate-600 mt-2">Real-time payment status confirmation with bank systems</p>
      </div>

      {/* Feature Card */}

      {/* Statistics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
        <div className="bg-gradient-to-br from-green-500 to-green-600 rounded-lg p-4 text-white">
          <div className="flex items-center gap-2 mb-2">
            <CheckCircle size={20} />
            <span className="text-sm">Completed</span>
          </div>
          <div className="text-3xl font-bold">{completedCount}</div>
          <div className="text-sm text-green-100">Successfully verified</div>
        </div>

        <div className="bg-gradient-to-br from-yellow-500 to-yellow-600 rounded-lg p-4 text-white">
          <div className="flex items-center gap-2 mb-2">
            <Clock size={20} />
            <span className="text-sm">Pending</span>
          </div>
          <div className="text-3xl font-bold">{pendingCount}</div>
          <div className="text-sm text-yellow-100">In progress</div>
        </div>

        <div className="bg-gradient-to-br from-red-500 to-red-600 rounded-lg p-4 text-white">
          <div className="flex items-center gap-2 mb-2">
            <XCircle size={20} />
            <span className="text-sm">Failed</span>
          </div>
          <div className="text-3xl font-bold">{failedCount}</div>
          <div className="text-sm text-red-100">Requires attention</div>
        </div>
      </div>

      {/* Verification Activity Feed */}
      <div className="bg-white rounded-lg shadow mb-8">
        <div className="p-6 border-b border-slate-200">
          <h2 className="text-xl font-bold text-slate-900">Recent Verification Activity</h2>
        </div>
        <div className="p-6">
          <div className="space-y-3">
            <div className="flex items-start gap-3 p-3 bg-green-50 rounded-lg">
              <CheckCircle className="text-green-600 mt-0.5" size={20} />
              <div className="flex-1">
                <p className="text-sm font-medium text-green-900">Payment BV-002 verified successfully</p>
                <p className="text-xs text-green-700">Industrial Supply Co. - $3,850.00 completed in 2h 15m</p>
                <p className="text-xs text-green-600 mt-1">2 hours ago</p>
              </div>
            </div>

            <div className="flex items-start gap-3 p-3 bg-blue-50 rounded-lg">
              <RefreshCw className="text-blue-600 mt-0.5" size={20} />
              <div className="flex-1">
                <p className="text-sm font-medium text-blue-900">Verifying payment BV-003 status</p>
                <p className="text-xs text-blue-700">PrintPro Solutions - $2,100.00 processing (retry 2/5)</p>
                <p className="text-xs text-blue-600 mt-1">5 minutes ago</p>
              </div>
            </div>

            <div className="flex items-start gap-3 p-3 bg-red-50 rounded-lg">
              <XCircle className="text-red-600 mt-0.5" size={20} />
              <div className="flex-1">
                <p className="text-sm font-medium text-red-900">Payment BV-005 failed - Action required</p>
                <p className="text-xs text-red-700">Dell Technologies - $12,475.00 returned by bank</p>
                <p className="text-xs text-red-600 mt-1">3 days ago</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Transactions List */}
      <div className="bg-white rounded-lg shadow">
        <div className="p-6 border-b border-slate-200 flex items-center justify-between">
          <h2 className="text-xl font-bold text-slate-900">Bank Transactions</h2>

          <div className="flex items-center gap-2">
            <span className="text-sm text-slate-500">Filter:</span>
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value as any)}
              className="border border-slate-300 rounded-md px-3 py-1 text-sm bg-white"
            >
              <option value="all">All</option>
              <option value="completed">Completed</option>
              <option value="pending">Pending</option>
              <option value="processing">Processing</option>
              <option value="failed">Failed</option>
            </select>
          </div>
        </div>

        <div className="divide-y divide-slate-200">
          {filteredTransactions.map((transaction) => {
            const bankBadge = getBankStatusBadge(transaction.bankStatus);
            const verificationBadge = getVerificationBadge(transaction.verificationStatus);
            const BankIcon = bankBadge.icon;
            const VerifyIcon = verificationBadge.icon;

            return (
              <div
                key={transaction.id}
                className="p-6 hover:bg-slate-50 cursor-pointer transition-colors"
                onClick={() => setSelectedTransaction(transaction)}
              >
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-3">
                      <h3 className="font-bold text-slate-900">{transaction.id}</h3>
                      <span className={`px-3 py-1 rounded-full text-xs font-medium ${bankBadge.color} flex items-center gap-1`}>
                        <BankIcon size={12} className={transaction.bankStatus === 'processing' ? 'animate-spin' : ''} />
                        {bankBadge.label}
                      </span>
                      <span className={`px-3 py-1 rounded-full text-xs font-medium ${verificationBadge.color} flex items-center gap-1`}>
                        <VerifyIcon size={12} className={transaction.verificationStatus === 'verifying' ? 'animate-spin' : ''} />
                        {verificationBadge.label}
                      </span>
                    </div>

                    <div className="grid grid-cols-4 gap-4 mb-3">
                      <div>
                        <p className="text-xs text-slate-500">Payment ID</p>
                        <p className="text-sm font-medium text-slate-900">{transaction.paymentId}</p>
                      </div>
                      <div>
                        <p className="text-xs text-slate-500">Supplier</p>
                        <p className="text-sm font-medium text-slate-900">{transaction.supplier}</p>
                      </div>
                      <div>
                        <p className="text-xs text-slate-500">Bank Reference</p>
                        <p className="text-sm font-medium text-slate-900">{transaction.bankReference}</p>
                      </div>
                      <div>
                        <p className="text-xs text-slate-500">Initiated</p>
                        <p className="text-sm font-medium text-slate-900">{transaction.initiatedDate}</p>
                      </div>
                    </div>

                    <div className="bg-orange-50 border border-orange-200 rounded-lg p-3">
                      <div className="flex items-start gap-2">
                        <Building2 className="text-orange-600 mt-0.5" size={16} />
                        <div className="flex-1">
                          <p className="text-sm font-medium text-orange-900">BV-1: Bank Status Verification</p>
                          <div className="flex items-center gap-4 text-xs text-orange-700 mt-2">
                            <span>Last checked: {transaction.lastChecked}</span>
                            <span>•</span>
                            <span>Verification attempts: {transaction.retryCount}</span>
                            <span>•</span>
                            <span>Bank: {transaction.verificationDetails.bankName}</span>
                          </div>
                        </div>
                      </div>
                    </div>

                    {transaction.errorMessage && (
                      <div className="bg-red-50 border border-red-200 rounded-lg p-3 mt-3">
                        <div className="flex items-start gap-2">
                          <AlertTriangle className="text-red-600 mt-0.5" size={16} />
                          <div>
                            <p className="text-sm font-medium text-red-900">Error Detected</p>
                            <p className="text-sm text-red-700">{transaction.errorMessage}</p>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>

                  <div className="text-right ml-4">
                    <div className="text-2xl font-bold text-slate-900">{transaction.amount}</div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Selected Transaction Details Modal */}
      {selectedTransaction && (
        <div
          className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-8"
          onClick={() => setSelectedTransaction(null)}
        >
          <div
            className="bg-white rounded-lg shadow-xl max-w-3xl w-full max-h-[90vh] overflow-auto"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="p-6 border-b border-slate-200">
              <h2 className="text-2xl font-bold text-slate-900">Bank Verification: {selectedTransaction.id}</h2>
            </div>

            <div className="p-6 space-y-6">
              {/* Transaction Overview */}
              <div className="bg-slate-50 rounded-lg p-4">
                <h3 className="font-semibold text-slate-900 mb-3">Transaction Details</h3>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-xs text-slate-500 mb-1">Payment ID</p>
                    <p className="font-medium text-slate-900">{selectedTransaction.paymentId}</p>
                  </div>
                  <div>
                    <p className="text-xs text-slate-500 mb-1">Bank Reference</p>
                    <p className="font-medium text-slate-900">{selectedTransaction.bankReference}</p>
                  </div>
                  <div>
                    <p className="text-xs text-slate-500 mb-1">Supplier</p>
                    <p className="font-medium text-slate-900">{selectedTransaction.supplier}</p>
                  </div>
                  <div>
                    <p className="text-xs text-slate-500 mb-1">Amount</p>
                    <p className="text-2xl font-bold text-slate-900">{selectedTransaction.amount}</p>
                  </div>
                </div>
              </div>

              {/* BV-1: Bank Verification */}
              <div className="bg-orange-50 border border-orange-200 rounded-lg p-4">
                <div className="flex items-start gap-3">
                  <Building2 className="text-orange-600 mt-1" size={24} />
                  <div className="flex-1">
                    <h3 className="font-semibold text-orange-900 mb-3">BV-1: Automatic Bank Status Confirmation</h3>

                    <div className="bg-white rounded-lg p-4 space-y-3">
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <p className="text-sm font-medium text-slate-900 mb-1">Bank Status</p>
                          <span className={`inline-flex items-center gap-2 px-3 py-1.5 rounded-full text-sm font-medium ${getBankStatusBadge(selectedTransaction.bankStatus).color}`}>
                            {selectedTransaction.bankStatus === 'completed' && <CheckCircle size={16} />}
                            {selectedTransaction.bankStatus === 'failed' && <XCircle size={16} />}
                            {selectedTransaction.bankStatus === 'processing' && <RefreshCw size={16} className="animate-spin" />}
                            {selectedTransaction.bankStatus === 'pending' && <Clock size={16} />}
                            {getBankStatusBadge(selectedTransaction.bankStatus).label}
                          </span>
                        </div>
                        <div>
                          <p className="text-sm font-medium text-slate-900 mb-1">Verification Status</p>
                          <span className={`inline-flex items-center gap-2 px-3 py-1.5 rounded-full text-sm font-medium ${getVerificationBadge(selectedTransaction.verificationStatus).color}`}>
                            {selectedTransaction.verificationStatus === 'verified' && <CheckCircle size={16} />}
                            {selectedTransaction.verificationStatus === 'error' && <XCircle size={16} />}
                            {selectedTransaction.verificationStatus === 'verifying' && <RefreshCw size={16} className="animate-spin" />}
                            {selectedTransaction.verificationStatus === 'not_verified' && <Clock size={16} />}
                            {getVerificationBadge(selectedTransaction.verificationStatus).label}
                          </span>
                        </div>
                      </div>

                      <div className="pt-3 border-t border-slate-200">
                        <p className="text-sm font-medium text-slate-900 mb-2">Bank Details</p>
                        <div className="space-y-2">
                          <div className="flex justify-between text-sm">
                            <span className="text-slate-600">Bank Name:</span>
                            <span className="font-medium text-slate-900">{selectedTransaction.verificationDetails.bankName}</span>
                          </div>
                          <div className="flex justify-between text-sm">
                            <span className="text-slate-600">Account Number:</span>
                            <span className="font-medium text-slate-900">{selectedTransaction.verificationDetails.accountNumber}</span>
                          </div>
                          <div className="flex justify-between text-sm">
                            <span className="text-slate-600">Transaction Type:</span>
                            <span className="font-medium text-slate-900">{selectedTransaction.verificationDetails.transactionType}</span>
                          </div>
                          <div className="flex justify-between text-sm">
                            <span className="text-slate-600">Processing Time:</span>
                            <span className="font-medium text-slate-900">{selectedTransaction.verificationDetails.processingTime}</span>
                          </div>
                        </div>
                      </div>

                      <div className="pt-3 border-t border-slate-200">
                        <p className="text-sm font-medium text-slate-900 mb-2">Verification Activity</p>
                        <div className="space-y-2">
                          <div className="flex justify-between text-sm">
                            <span className="text-slate-600">Initiated:</span>
                            <span className="font-medium text-slate-900">{selectedTransaction.initiatedDate}</span>
                          </div>
                          <div className="flex justify-between text-sm">
                            <span className="text-slate-600">Last Checked:</span>
                            <span className="font-medium text-slate-900">{selectedTransaction.lastChecked}</span>
                          </div>
                          <div className="flex justify-between text-sm">
                            <span className="text-slate-600">Verification Attempts:</span>
                            <span className="font-medium text-slate-900">{selectedTransaction.retryCount}</span>
                          </div>
                        </div>
                      </div>

                      {selectedTransaction.errorMessage && (
                        <div className="pt-3 border-t border-red-200 bg-red-50 -m-4 p-4 mt-3">
                          <div className="flex items-start gap-2">
                            <AlertTriangle className="text-red-600 mt-0.5" size={20} />
                            <div>
                              <p className="text-sm font-medium text-red-900 mb-1">Error Details</p>
                              <p className="text-sm text-red-700">{selectedTransaction.errorMessage}</p>
                            </div>
                          </div>
                        </div>
                      )}
                    </div>

                    <p className="text-xs text-orange-600 mt-3">
                      AI continuously monitors bank APIs to confirm payment status in real-time, automatically retrying verification up to 5 times for pending transactions
                    </p>
                  </div>
                </div>
              </div>

              {/* Verification Timeline */}
              <div className="bg-slate-50 border border-slate-200 rounded-lg p-4">
                <h3 className="font-semibold text-slate-900 mb-3">Verification Timeline</h3>
                <div className="space-y-3">
                  <div className="flex items-start gap-3">
                    <div className="w-8 h-8 rounded-full bg-blue-600 flex items-center justify-center text-white text-xs font-bold">1</div>
                    <div>
                      <p className="text-sm font-medium text-slate-900">Payment Initiated</p>
                      <p className="text-xs text-slate-600">{selectedTransaction.initiatedDate}</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <div className="w-8 h-8 rounded-full bg-blue-600 flex items-center justify-center text-white text-xs font-bold">2</div>
                    <div>
                      <p className="text-sm font-medium text-slate-900">Bank Verification Started</p>
                      <p className="text-xs text-slate-600">Automatic API call to bank system</p>
                    </div>
                  </div>
                  {selectedTransaction.bankStatus === 'completed' && (
                    <div className="flex items-start gap-3">
                      <div className="w-8 h-8 rounded-full bg-green-600 flex items-center justify-center text-white text-xs font-bold">✓</div>
                      <div>
                        <p className="text-sm font-medium text-green-900">Payment Confirmed</p>
                        <p className="text-xs text-green-700">Successfully verified with bank</p>
                      </div>
                    </div>
                  )}
                  {selectedTransaction.bankStatus === 'failed' && (
                    <div className="flex items-start gap-3">
                      <div className="w-8 h-8 rounded-full bg-red-600 flex items-center justify-center text-white text-xs font-bold">✗</div>
                      <div>
                        <p className="text-sm font-medium text-red-900">Payment Failed</p>
                        <p className="text-xs text-red-700">Rejected by bank - Action required</p>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>

            <div className="p-6 border-t border-slate-200 flex justify-end gap-3">
              {selectedTransaction.bankStatus === 'failed' && (
                <button className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
                  Retry Payment
                </button>
              )}
              {selectedTransaction.verificationStatus === 'verifying' && (
                <button className="px-6 py-2 bg-orange-600 text-white rounded-lg hover:bg-orange-700 transition-colors flex items-center gap-2">
                  <RefreshCw size={16} className="animate-spin" />
                  Refresh Status
                </button>
              )}
              <button
                onClick={() => setSelectedTransaction(null)}
                className="px-6 py-2 bg-slate-900 text-white rounded-lg hover:bg-slate-800 transition-colors"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}