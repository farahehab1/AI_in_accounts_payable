import { Link } from "react-router";
import { ShoppingCart, FileText, CreditCard, Building2, BookOpen, TrendingUp, AlertCircle, CheckCircle, Clock, BarChart3 } from "lucide-react";

export function Dashboard() {
  const stats = [
    { label: "Active Purchase Orders", value: "24", change: "+12%", trend: "up", icon: ShoppingCart, color: "bg-blue-500" },
    { label: "Pending Invoices", value: "18", change: "-8%", trend: "down", icon: FileText, color: "bg-purple-500" },
    { label: "Payments Scheduled", value: "31", change: "+5%", trend: "up", icon: CreditCard, color: "bg-green-500" },
    { label: "Bank Verifications", value: "42", change: "0%", trend: "neutral", icon: Building2, color: "bg-orange-500" },
  ];

  const recentActivity = [
    { id: 1, type: "PO", message: "AI identified need for office supplies", time: "5 min ago", status: "success" },
    { id: 2, type: "Invoice", message: "Auto-matched invoice #INV-2024-0428 with PO-0315", time: "12 min ago", status: "success" },
    { id: 3, type: "Payment", message: "Payment approval prediction: No approval needed", time: "18 min ago", status: "info" },
    { id: 4, type: "GR", message: "AI confirmed receipt of goods for PO-0312", time: "25 min ago", status: "success" },
    { id: 5, type: "Bank", message: "Payment status verified: Completed", time: "32 min ago", status: "success" },
    { id: 6, type: "Accounting", message: "Financial records updated automatically", time: "45 min ago", status: "success" },
  ];

  const aiInsights = [
    { title: "Procurement Efficiency", value: "94%", description: "AI automation reduced manual work by 78%" },
    { title: "Invoice Match Rate", value: "96.5%", description: "Automated matching with 99.2% accuracy" },
    { title: "Payment Optimization", value: "$42K", description: "Saved through optimized payment scheduling" },
  ];

  return (
    <div className="p-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-slate-900">Dashboard</h1>
        <p className="text-slate-600 mt-2">AI-powered automation across the accounts payable process</p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {stats.map((stat) => {
          const Icon = stat.icon;
          return (
            <div key={stat.label} className="bg-white rounded-lg shadow p-6">
              <div className="flex items-center justify-between mb-4">
                <div className={`${stat.color} w-12 h-12 rounded-lg flex items-center justify-center`}>
                  <Icon className="text-white" size={24} />
                </div>
                <span className={`text-sm font-medium ${stat.trend === 'up' ? 'text-green-600' : stat.trend === 'down' ? 'text-red-600' : 'text-slate-600'}`}>
                  {stat.change}
                </span>
              </div>
              <div className="text-2xl font-bold text-slate-900">{stat.value}</div>
              <div className="text-sm text-slate-600 mt-1">{stat.label}</div>
            </div>
          );
        })}
      </div>

      {/* AI Insights */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
        {aiInsights.map((insight) => (
          null
        ))}
      </div>

      {/* Recent Activity */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-lg shadow">
          <div className="p-6 border-b border-slate-200">
            <h2 className="text-xl font-bold text-slate-900">Recent AI Activity</h2>
          </div>
          <div className="p-6">
            <div className="space-y-4">
              {recentActivity.map((activity) => (
                <div key={activity.id} className="flex items-start gap-4">
                  <div className={`mt-1 ${activity.status === 'success' ? 'text-green-600' : activity.status === 'warning' ? 'text-orange-600' : 'text-blue-600'}`}>
                    {activity.status === 'success' ? <CheckCircle size={20} /> : <AlertCircle size={20} />}
                  </div>
                  <div className="flex-1">
                    <p className="text-sm text-slate-900">{activity.message}</p>
                    <div className="flex items-center gap-2 mt-1">
                      <span className="text-xs px-2 py-1 bg-slate-100 text-slate-700 rounded">{activity.type}</span>
                      <span className="text-xs text-slate-500">{activity.time}</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Quick Actions */}
        <div className="bg-white rounded-lg shadow">
          <div className="p-6 border-b border-slate-200">
            <h2 className="text-xl font-bold text-slate-900">Quick Access</h2>
          </div>
          <div className="p-6">
            <div className="space-y-3">
              <Link to="/purchase-orders" className="block p-4 border border-slate-200 rounded-lg hover:border-blue-500 hover:bg-blue-50 transition-colors">
                <div className="flex items-center gap-3">
                  <ShoppingCart className="text-blue-600" size={20} />
                  <div>
                    <h3 className="font-semibold text-slate-900">Purchase Orders</h3>
                    <p className="text-xs text-slate-600">AI-identified needs & auto-generated POs</p>
                  </div>
                </div>
              </Link>

              <Link to="/invoices" className="block p-4 border border-slate-200 rounded-lg hover:border-purple-500 hover:bg-purple-50 transition-colors">
                <div className="flex items-center gap-3">
                  <FileText className="text-purple-600" size={20} />
                  <div>
                    <h3 className="font-semibold text-slate-900">Invoice Handling</h3>
                    <p className="text-xs text-slate-600">Auto-extraction & intelligent matching</p>
                  </div>
                </div>
              </Link>

              <Link to="/payments" className="block p-4 border border-slate-200 rounded-lg hover:border-green-500 hover:bg-green-50 transition-colors">
                <div className="flex items-center gap-3">
                  <CreditCard className="text-green-600" size={20} />
                  <div>
                    <h3 className="font-semibold text-slate-900">Payments & Bank Verification</h3>
                    <p className="text-xs text-slate-600">Approval prediction, scheduling & real-time bank status</p>
                  </div>
                </div>
              </Link>

              <Link to="/accounting" className="block p-4 border border-slate-200 rounded-lg hover:border-slate-500 hover:bg-slate-50 transition-colors">
                <div className="flex items-center gap-3">
                  <BookOpen className="text-slate-600" size={20} />
                  <div>
                    <h3 className="font-semibold text-slate-900">Accounting Records</h3>
                    <p className="text-xs text-slate-600">Automatic financial record updates</p>
                  </div>
                </div>
              </Link>

              <Link to="/reports" className="block p-4 border border-slate-200 rounded-lg hover:border-indigo-500 hover:bg-indigo-50 transition-colors">
                <div className="flex items-center gap-3">
                  <BarChart3 className="text-indigo-600" size={20} />
                  <div>
                    <h3 className="font-semibold text-slate-900">Supplier Reports</h3>
                    <p className="text-xs text-slate-600">Monthly, quarterly & yearly outstanding balances</p>
                  </div>
                </div>
              </Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
