import { useState } from "react";
import { FileText, Scan, Link2, CheckCircle, XCircle, AlertTriangle } from "lucide-react";

interface Invoice {
  id: string;
  supplier: string;
  invoiceNumber: string;
  invoiceDate: string;
  dueDate: string;
  amount: string;
  extractionStatus: "processing" | "completed" | "error";
  extractedData: {
    invoiceNumber: string;
    date: string;
    amount: string;
    items: string;
    taxAmount: string;
  };
  matchingStatus: "matched" | "partial_match" | "no_match" | "discrepancy";
  matchedPO?: string;
  matchedGR?: string;
  discrepancies?: string[];
  confidence: number;
}

export function InvoiceHandling() {
  const [selectedInvoice, setSelectedInvoice] = useState<Invoice | null>(null);
  const [searchTerm, setSearchTerm] = useState("");

  const invoices: Invoice[] = [
    {
      id: "INV-001",
      supplier: "Office Depot Inc.",
      invoiceNumber: "OD-2024-4521",
      invoiceDate: "2026-04-18",
      dueDate: "2026-05-18",
      amount: "$1,245.00",
      extractionStatus: "completed",
      extractedData: {
        invoiceNumber: "OD-2024-4521",
        date: "2026-04-18",
        amount: "$1,245.00",
        items: "Paper reams (50), Printer ink (12), Pens (100)",
        taxAmount: "$45.00"
      },
      matchingStatus: "matched",
      matchedPO: "PO-0315",
      matchedGR: "GR-0287",
      confidence: 99
    },
    {
      id: "INV-002",
      supplier: "Industrial Supply Co.",
      invoiceNumber: "ISC-78921",
      invoiceDate: "2026-04-19",
      dueDate: "2026-05-19",
      amount: "$3,850.00",
      extractionStatus: "completed",
      extractedData: {
        invoiceNumber: "ISC-78921",
        date: "2026-04-19",
        amount: "$3,850.00",
        items: "Cleaning supplies, Safety equipment, Maintenance tools",
        taxAmount: "$150.00"
      },
      matchingStatus: "matched",
      matchedPO: "PO-0317",
      matchedGR: "GR-0289",
      confidence: 97
    },
    {
      id: "INV-003",
      supplier: "Dell Technologies",
      invoiceNumber: "DELL-INV-9845",
      invoiceDate: "2026-04-20",
      dueDate: "2026-05-20",
      amount: "$12,475.00",
      extractionStatus: "completed",
      extractedData: {
        invoiceNumber: "DELL-INV-9845",
        date: "2026-04-20",
        amount: "$12,475.00",
        items: "Dell XPS 15 (5 units), USB-C Docks (5 units)",
        taxAmount: "$475.00"
      },
      matchingStatus: "discrepancy",
      matchedPO: "PO-0316",
      matchedGR: "GR-0290",
      discrepancies: ["Amount mismatch: PO shows $12,500.00, Invoice shows $12,475.00 (promotional discount applied)"],
      confidence: 92
    },
    {
      id: "INV-004",
      supplier: "PrintPro Solutions",
      invoiceNumber: "PP-2024-1156",
      invoiceDate: "2026-04-21",
      dueDate: "2026-05-21",
      amount: "$2,100.00",
      extractionStatus: "processing",
      extractedData: {
        invoiceNumber: "PP-2024-1156",
        date: "2026-04-21",
        amount: "$2,100.00",
        items: "Extracting...",
        taxAmount: "$100.00"
      },
      matchingStatus: "partial_match",
      matchedPO: "PO-0318",
      confidence: 85
    },
    {
      id: "INV-005",
      supplier: "Unknown Supplier",
      invoiceNumber: "UNK-12345",
      invoiceDate: "2026-04-22",
      dueDate: "2026-05-22",
      amount: "$850.00",
      extractionStatus: "completed",
      extractedData: {
        invoiceNumber: "UNK-12345",
        date: "2026-04-22",
        amount: "$850.00",
        items: "Miscellaneous office items",
        taxAmount: "$50.00"
      },
      matchingStatus: "no_match",
      confidence: 45
    }
  ];

  // ✅ CHANGED ONLY THIS LINE (supplier search instead of id)
  const filteredInvoices = invoices.filter((invoice) =>
    invoice.supplier.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const getMatchingBadge = (status: Invoice["matchingStatus"]) => {
    const badges = {
      matched: { label: "Matched", color: "bg-green-100 text-green-800", icon: CheckCircle },
      partial_match: { label: "Partial Match", color: "bg-yellow-100 text-yellow-800", icon: AlertTriangle },
      no_match: { label: "No Match", color: "bg-red-100 text-red-800", icon: XCircle },
      discrepancy: { label: "Discrepancy", color: "bg-orange-100 text-orange-800", icon: AlertTriangle }
    };
    return badges[status];
  };

  const getExtractionBadge = (status: Invoice["extractionStatus"]) => {
    const badges = {
      processing: { label: "Processing", color: "bg-blue-100 text-blue-800" },
      completed: { label: "Extracted", color: "bg-green-100 text-green-800" },
      error: { label: "Error", color: "bg-red-100 text-red-800" }
    };
    return badges[status];
  };

  return (
    <div className="p-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-slate-900">Invoice Handling</h1>
        <p className="text-slate-600 mt-2">AI-powered data extraction and intelligent matching</p>
      </div>

      <div className="bg-white rounded-lg shadow">
        <div className="p-6 border-b border-slate-200 flex items-center justify-between gap-4">
          <h2 className="text-xl font-bold text-slate-900">Recent Invoices</h2>

          <div className="flex items-center gap-2">
            <input
              type="text"
              placeholder="Search by Supplier..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            />

            <button className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
              Upload Invoice
            </button>
          </div>
        </div>

        <div className="divide-y divide-slate-200">
          {filteredInvoices.map((invoice) => {
            const matchingBadge = getMatchingBadge(invoice.matchingStatus);
            const extractionBadge = getExtractionBadge(invoice.extractionStatus);
            const MatchIcon = matchingBadge.icon;

            return (
              <div
                key={invoice.id}
                className="p-6 hover:bg-slate-50 cursor-pointer transition-colors"
                onClick={() => setSelectedInvoice(invoice)}
              >
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-3">
                      <h3 className="font-bold text-slate-900">{invoice.invoiceNumber}</h3>
                      <span className={`px-3 py-1 rounded-full text-xs font-medium ${extractionBadge.color}`}>
                        {extractionBadge.label}
                      </span>
                      <span className={`px-3 py-1 rounded-full text-xs font-medium ${matchingBadge.color} flex items-center gap-1`}>
                        <MatchIcon size={12} />
                        {matchingBadge.label}
                      </span>
                    </div>

                    <div className="grid grid-cols-3 gap-4">
                      <div>
                        <p className="text-xs text-slate-500">Supplier</p>
                        <p className="text-sm font-medium text-slate-900">{invoice.supplier}</p>
                      </div>
                      <div>
                        <p className="text-xs text-slate-500">Invoice Date</p>
                        <p className="text-sm font-medium text-slate-900">{invoice.invoiceDate}</p>
                      </div>
                      <div>
                        <p className="text-xs text-slate-500">Due Date</p>
                        <p className="text-sm font-medium text-slate-900">{invoice.dueDate}</p>
                      </div>
                    </div>

                    {invoice.matchedPO && (
                      <div className="mt-3 flex items-center gap-2 text-sm">
                        <Link2 className="text-blue-600" size={16} />
                        <span className="text-slate-600">Matched to</span>
                        <span className="font-medium text-blue-600">{invoice.matchedPO}</span>
                        {invoice.matchedGR && (
                          <>
                            <span className="text-slate-400">•</span>
                            <span className="font-medium text-blue-600">{invoice.matchedGR}</span>
                          </>
                        )}
                      </div>
                    )}

                    {invoice.discrepancies && invoice.discrepancies.length > 0 && (
                      <div className="mt-3 bg-orange-50 border border-orange-200 rounded p-3">
                        <p className="text-sm font-medium text-orange-900 mb-1">Discrepancies Detected:</p>
                        {invoice.discrepancies.map((disc, idx) => (
                          <p key={idx} className="text-sm text-orange-700">• {disc}</p>
                        ))}
                      </div>
                    )}
                  </div>

                  <div className="text-right ml-4">
                    <div className="text-2xl font-bold text-slate-900">{invoice.amount}</div>
                    <div className="mt-2">
                      <div className="text-xs text-slate-500 mb-1">AI Confidence</div>
                      <div className="flex items-center gap-2">
                        <div className="w-24 bg-slate-200 rounded-full h-2">
                          <div
                            className={`h-2 rounded-full ${invoice.confidence >= 90 ? 'bg-green-600' : invoice.confidence >= 70 ? 'bg-yellow-600' : 'bg-red-600'}`}
                            style={{ width: `${invoice.confidence}%` }}
                          ></div>
                        </div>
                        <span className="text-xs font-medium text-slate-700">{invoice.confidence}%</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Selected Invoice Details Modal */}
      {selectedInvoice && (
        <div
          className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-8"
          onClick={() => setSelectedInvoice(null)}
        >
          <div
            className="bg-white rounded-lg shadow-xl max-w-3xl w-full max-h-[90vh] overflow-auto"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="p-6 border-b border-slate-200">
              <h2 className="text-2xl font-bold text-slate-900">Invoice Details: {selectedInvoice.invoiceNumber}</h2>
            </div>

            <div className="p-6 space-y-6">
              {/* IH-1: Data Extraction */}
              <div className="bg-purple-50 border border-purple-200 rounded-lg p-4">
                <div className="flex items-start gap-3">
                  <Scan className="text-purple-600 mt-1" size={24} />
                  <div className="flex-1">
                    <h3 className="font-semibold text-purple-900 mb-3">IH-1: AI Data Extraction</h3>

                    <div className="bg-white rounded-lg p-4 space-y-3">
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <p className="text-xs text-slate-500 mb-1">Invoice Number</p>
                          <p className="text-sm font-medium text-slate-900">{selectedInvoice.extractedData.invoiceNumber}</p>
                        </div>
                        <div>
                          <p className="text-xs text-slate-500 mb-1">Date</p>
                          <p className="text-sm font-medium text-slate-900">{selectedInvoice.extractedData.date}</p>
                        </div>
                        <div>
                          <p className="text-xs text-slate-500 mb-1">Amount</p>
                          <p className="text-sm font-medium text-slate-900">{selectedInvoice.extractedData.amount}</p>
                        </div>
                        <div>
                          <p className="text-xs text-slate-500 mb-1">Tax Amount</p>
                          <p className="text-sm font-medium text-slate-900">{selectedInvoice.extractedData.taxAmount}</p>
                        </div>
                      </div>
                      <div>
                        <p className="text-xs text-slate-500 mb-1">Items</p>
                        <p className="text-sm font-medium text-slate-900">{selectedInvoice.extractedData.items}</p>
                      </div>
                    </div>

                    <p className="text-xs text-purple-600 mt-3">
                      Extracted using AI-powered OCR and NLP in {selectedInvoice.extractionStatus === 'completed' ? '3.2 seconds' : 'processing...'}
                    </p>
                  </div>
                </div>
              </div>

              {/* IH-2: Matching */}
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                <div className="flex items-start gap-3">
                  <Link2 className="text-blue-600 mt-1" size={24} />
                  <div className="flex-1">
                    <h3 className="font-semibold text-blue-900 mb-3">IH-2: Intelligent Matching</h3>

                    {selectedInvoice.matchingStatus === 'matched' && (
                      <div className="space-y-3">
                        <div className="flex items-center gap-2 text-green-700">
                          <CheckCircle size={20} />
                          <span className="font-medium">Successfully matched with PO and GR</span>
                        </div>

                        <div className="bg-white rounded-lg p-4">
                          <div className="space-y-2">
                            <div className="flex items-center justify-between py-2 border-b border-slate-200">
                              <span className="text-sm text-slate-600">Purchase Order</span>
                              <span className="font-medium text-blue-600">{selectedInvoice.matchedPO}</span>
                            </div>
                            <div className="flex items-center justify-between py-2 border-b border-slate-200">
                              <span className="text-sm text-slate-600">Goods Receipt</span>
                              <span className="font-medium text-blue-600">{selectedInvoice.matchedGR}</span>
                            </div>
                            <div className="flex items-center justify-between py-2">
                              <span className="text-sm text-slate-600">Match Confidence</span>
                              <span className="font-bold text-green-600">{selectedInvoice.confidence}%</span>
                            </div>
                          </div>
                        </div>

                        <div className="grid grid-cols-3 gap-2 text-xs">
                          <div className="flex items-center gap-1 text-green-700">
                            <CheckCircle size={14} />
                            <span>Amounts match</span>
                          </div>
                          <div className="flex items-center gap-1 text-green-700">
                            <CheckCircle size={14} />
                            <span>Items verified</span>
                          </div>
                          <div className="flex items-center gap-1 text-green-700">
                            <CheckCircle size={14} />
                            <span>Supplier confirmed</span>
                          </div>
                        </div>
                      </div>
                    )}

                    {selectedInvoice.matchingStatus === 'discrepancy' && (
                      <div className="space-y-3">
                        <div className="flex items-center gap-2 text-orange-700">
                          <AlertTriangle size={20} />
                          <span className="font-medium">Discrepancies detected - Review required</span>
                        </div>

                        <div className="bg-white rounded-lg p-4">
                          {selectedInvoice.discrepancies?.map((disc, idx) => (
                            <div key={idx} className="flex items-start gap-2 py-2">
                              <AlertTriangle className="text-orange-600 mt-0.5" size={16} />
                              <p className="text-sm text-slate-900">{disc}</p>
                            </div>
                          ))}
                        </div>

                        <p className="text-xs text-orange-600">
                          AI detected variance - Flagged for accountant review to prevent payment errors
                        </p>
                      </div>
                    )}

                    {selectedInvoice.matchingStatus === 'no_match' && (
                      <div className="space-y-3">
                        <div className="flex items-center gap-2 text-red-700">
                          <XCircle size={20} />
                          <span className="font-medium">No matching PO or GR found</span>
                        </div>

                        <p className="text-sm text-red-800">
                          This invoice could not be automatically matched. Manual review required.
                        </p>
                      </div>
                    )}

                    <p className="text-xs text-blue-600 mt-3">
                      AI matching algorithm analyzes PO numbers, amounts, dates, suppliers, and line items
                    </p>
                  </div>
                </div>
              </div>
            </div>

            <div className="p-6 border-t border-slate-200 flex justify-end">
              <button
                onClick={() => setSelectedInvoice(null)}
                className="px-6 py-2 bg-slate-900 text-white rounded-lg hover:bg-slate-800 transition-colors"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}