import { useState } from "react";
import { CreditCard, Shield, Calendar, CheckCircle, AlertCircle, Clock, Building2, RefreshCw, XCircle, AlertTriangle } from "lucide-react";

interface Payment {
  id: string;
  invoiceNumber: string;
  supplier: string;
  amount: string;
  dueDate: string;
  scheduledDate: string;
  status: "pending_approval" | "approved" | "scheduled" | "processing" | "completed";
  approvalRequired: boolean;
  approvalPrediction: string;
  approvalConfidence: number;
  schedulingReason: string;
  cashFlowImpact: string;
  riskLevel: "low" | "medium" | "high";
  bankVerification: {
    bankStatus: "completed" | "pending" | "failed" | "processing";
    verificationStatus: "verified" | "verifying" | "error" | "not_verified";
    bankReference: string;
    lastChecked: string;
    retryCount: number;
    errorMessage?: string;
    bankName: string;
    accountNumber: string;
    transactionType: string;
    processingTime: string;
    initiatedDate: string;
  };
}

export function PaymentProcessing() {
  const [selectedPayment, setSelectedPayment] = useState<Payment | null>(null);
  const [statusFilter, setStatusFilter] = useState<"all" | Payment["status"]>("all");

  const payments: Payment[] = [
    {
      id: "PAY-001",
      invoiceNumber: "OD-2024-4521",
      supplier: "Office Depot Inc.",
      amount: "$1,245.00",
      dueDate: "2026-05-18",
      scheduledDate: "2026-05-15",
      status: "completed",
      approvalRequired: false,
      approvalPrediction: "No approval required - Standard expense under $5K threshold",
      approvalConfidence: 98,
      schedulingReason: "Scheduled 3 days before due date to maintain good supplier relationship and capture early payment discount",
      cashFlowImpact: "Minimal - Well within available balance",
      riskLevel: "low",
      bankVerification: {
        bankStatus: "completed",
        verificationStatus: "verified",
        bankReference: "BNK-REF-78945612",
        lastChecked: "2026-04-20 15:45",
        retryCount: 0,
        bankName: "Chase Business Bank",
        accountNumber: "****5678",
        transactionType: "ACH Transfer",
        processingTime: "1h 15m",
        initiatedDate: "2026-04-20 14:30"
      }
    },
    {
      id: "PAY-002",
      invoiceNumber: "DELL-INV-9845",
      supplier: "Dell Technologies",
      amount: "$12,475.00",
      dueDate: "2026-05-20",
      scheduledDate: "2026-05-18",
      status: "pending_approval",
      approvalRequired: true,
      approvalPrediction: "Approval required - High-value IT equipment purchase exceeds $10K threshold",
      approvalConfidence: 96,
      schedulingReason: "Optimized for 2-day early payment discount (2% = $249.50 savings)",
      cashFlowImpact: "Moderate - Requires cash reserve of $15K",
      riskLevel: "medium",
      bankVerification: {
        bankStatus: "failed",
        verificationStatus: "error",
        bankReference: "BNK-REF-78945611",
        lastChecked: "2026-04-19 14:30",
        retryCount: 3,
        errorMessage: "Insufficient funds in account - Payment returned by bank",
        bankName: "Chase Business Bank",
        accountNumber: "****5678",
        transactionType: "Wire Transfer",
        processingTime: "Failed after 3h 10m",
        initiatedDate: "2026-04-19 11:20"
      }
    },
    {
      id: "PAY-003",
      invoiceNumber: "ISC-78921",
      supplier: "Industrial Supply Co.",
      amount: "$3,850.00",
      dueDate: "2026-05-19",
      scheduledDate: "2026-05-17",
      status: "completed",
      approvalRequired: false,
      approvalPrediction: "No approval required - Recurring maintenance supplier with established payment history",
      approvalConfidence: 99,
      schedulingReason: "Scheduled to optimize cash flow - aligns with weekly payment batch processing",
      cashFlowImpact: "Low - Regular recurring expense",
      riskLevel: "low",
      bankVerification: {
        bankStatus: "completed",
        verificationStatus: "verified",
        bankReference: "BNK-REF-78945613",
        lastChecked: "2026-04-21 11:30",
        retryCount: 0,
        bankName: "Chase Business Bank",
        accountNumber: "****5678",
        transactionType: "Wire Transfer",
        processingTime: "2h 15m",
        initiatedDate: "2026-04-21 09:15"
      }
    },
    {
      id: "PAY-004",
      invoiceNumber: "PP-2024-1156",
      supplier: "PrintPro Solutions",
      amount: "$2,100.00",
      dueDate: "2026-05-21",
      scheduledDate: "2026-05-19",
      status: "scheduled",
      approvalRequired: false,
      approvalPrediction: "No approval required - Marketing expense within budget allocation",
      approvalConfidence: 94,
      schedulingReason: "Scheduled for maximum cash flow efficiency - utilizes end-of-week bank balance",
      cashFlowImpact: "Minimal - Marketing budget allocated",
      riskLevel: "low",
      bankVerification: {
        bankStatus: "processing",
        verificationStatus: "verifying",
        bankReference: "BNK-REF-78945614",
        lastChecked: "2026-04-22 09:30",
        retryCount: 2,
        bankName: "Chase Business Bank",
        accountNumber: "****5678",
        transactionType: "ACH Transfer",
        processingTime: "In progress",
        initiatedDate: "2026-04-21 16:45"
      }
    },
    {
      id: "PAY-005",
      invoiceNumber: "MS-LICENSE-Q2",
      supplier: "Microsoft Corporation",
      amount: "$7,500.00",
      dueDate: "2026-05-25",
      scheduledDate: "2026-05-23",
      status: "approved",
      approvalRequired: true,
      approvalPrediction: "Approval required - Software licensing renewal exceeds $5K threshold and requires CFO sign-off",
      approvalConfidence: 92,
      schedulingReason: "Scheduled to avoid service interruption while maximizing cash retention period",
      cashFlowImpact: "Moderate - Quarterly software expense",
      riskLevel: "medium",
      bankVerification: {
        bankStatus: "pending",
        verificationStatus: "not_verified",
        bankReference: "BNK-REF-78945615",
        lastChecked: "2026-04-22 10:00",
        retryCount: 0,
        bankName: "Chase Business Bank",
        accountNumber: "****5678",
        transactionType: "Wire Transfer",
        processingTime: "Pending",
        initiatedDate: "2026-04-22 08:00"
      }
    }
  ];

  const getStatusBadge = (status: Payment["status"]) => {
    const badges = {
      pending_approval: { label: "Pending Approval", color: "bg-orange-100 text-orange-800", icon: Clock },
      approved: { label: "Approved", color: "bg-green-100 text-green-800", icon: CheckCircle },
      scheduled: { label: "Scheduled", color: "bg-blue-100 text-blue-800", icon: Calendar },
      processing: { label: "Processing", color: "bg-purple-100 text-purple-800", icon: Clock },
      completed: { label: "Completed", color: "bg-slate-100 text-slate-800", icon: CheckCircle }
    };
    return badges[status];
  };

  const getRiskBadge = (risk: Payment["riskLevel"]) => {
    const badges = {
      low: { label: "Low Risk", color: "bg-green-100 text-green-800" },
      medium: { label: "Medium Risk", color: "bg-yellow-100 text-yellow-800" },
      high: { label: "High Risk", color: "bg-red-100 text-red-800" }
    };
    return badges[risk];
  };

  const getBankStatusBadge = (status: Payment["bankVerification"]["bankStatus"]) => {
    const badges = {
      completed: { label: "Bank: Completed", color: "bg-green-100 text-green-800", icon: CheckCircle },
      pending: { label: "Bank: Pending", color: "bg-yellow-100 text-yellow-800", icon: Clock },
      failed: { label: "Bank: Failed", color: "bg-red-100 text-red-800", icon: XCircle },
      processing: { label: "Bank: Processing", color: "bg-blue-100 text-blue-800", icon: RefreshCw }
    };
    return badges[status];
  };

  const filteredPayments = payments.filter((p) => {
    if (statusFilter === "all") return true;
    return p.status === statusFilter;
  });

  const totalScheduled = payments.filter(p => p.status === 'scheduled' || p.status === 'approved').length;
  const totalAmount = payments.reduce((sum, p) => sum + parseFloat(p.amount.replace(/[$,]/g, '')), 0);
  const pendingApproval = payments.filter(p => p.status === 'pending_approval').length;
  const bankCompleted = payments.filter(p => p.bankVerification.bankStatus === 'completed').length;
  const bankFailed = payments.filter(p => p.bankVerification.bankStatus === 'failed').length;

  return (
    <div className="p-8">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-slate-900">Payment Processing & Bank Verification</h1>
        <p className="text-slate-600 mt-2">AI-powered approval prediction, automated scheduling, and real-time bank verification</p>
      </div>

      {/* Statistics */}
      <div className="grid grid-cols-1 md:grid-cols-5 gap-4 mb-8">
        <div className="bg-white rounded-lg shadow p-4">
          <div className="text-sm text-slate-600 mb-1">Pending Approval</div>
          <div className="text-2xl font-bold text-orange-600">{pendingApproval}</div>
        </div>
        <div className="bg-white rounded-lg shadow p-4">
          <div className="text-sm text-slate-600 mb-1">Scheduled</div>
          <div className="text-2xl font-bold text-blue-600">{totalScheduled}</div>
        </div>
        <div className="bg-white rounded-lg shadow p-4">
          <div className="text-sm text-slate-600 mb-1">Bank Verified</div>
          <div className="text-2xl font-bold text-green-600">{bankCompleted}</div>
        </div>
        <div className="bg-white rounded-lg shadow p-4">
          <div className="text-sm text-slate-600 mb-1">Bank Failed</div>
          <div className="text-2xl font-bold text-red-600">{bankFailed}</div>
        </div>
        <div className="bg-white rounded-lg shadow p-4">
          <div className="text-sm text-slate-600 mb-1">Total Amount</div>
          <div className="text-2xl font-bold text-slate-900">${totalAmount.toFixed(2)}</div>
        </div>
      </div>

      {/* Payments List */}
      <div className="bg-white rounded-lg shadow">
        <div className="p-6 border-b border-slate-200 flex items-center justify-between">
          <h2 className="text-xl font-bold text-slate-900">Payment Queue & Bank Status</h2>

          <div className="flex items-center gap-3">
            <label className="text-sm font-medium text-slate-700">Filter:</label>
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value as any)}
              className="border border-slate-300 rounded-lg px-3 py-2 text-sm"
            >
              <option value="all">All</option>
              <option value="pending_approval">Pending Approval</option>
              <option value="approved">Approved</option>
              <option value="scheduled">Scheduled</option>
              <option value="completed">Completed</option>
            </select>
          </div>
        </div>

        <div className="divide-y divide-slate-200">
          {filteredPayments.map((payment) => {
            const statusBadge = getStatusBadge(payment.status);
            const riskBadge = getRiskBadge(payment.riskLevel);
            const bankBadge = getBankStatusBadge(payment.bankVerification.bankStatus);
            const StatusIcon = statusBadge.icon;
            const BankIcon = bankBadge.icon;

            return (
              <div
                key={payment.id}
                className="p-6 hover:bg-slate-50 cursor-pointer transition-colors"
                onClick={() => setSelectedPayment(payment)}
              >
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-3">
                      <h3 className="font-bold text-slate-900">{payment.id}</h3>
                      <span className={`px-3 py-1 rounded-full text-xs font-medium ${statusBadge.color} flex items-center gap-1`}>
                        <StatusIcon size={12} />
                        {statusBadge.label}
                      </span>
                      <span className={`px-3 py-1 rounded-full text-xs font-medium ${bankBadge.color} flex items-center gap-1`}>
                        <BankIcon size={12} className={payment.bankVerification.bankStatus === 'processing' ? 'animate-spin' : ''} />
                        {bankBadge.label}
                      </span>
                      <span className={`px-3 py-1 rounded-full text-xs font-medium ${riskBadge.color}`}>
                        {riskBadge.label}
                      </span>
                      {payment.approvalRequired && (
                        <span className="px-3 py-1 rounded-full text-xs font-medium bg-red-100 text-red-800">
                          Approval Required
                        </span>
                      )}
                    </div>

                    <div className="grid grid-cols-4 gap-4 mb-3">
                      <div>
                        <p className="text-xs text-slate-500">Supplier</p>
                        <p className="text-sm font-medium text-slate-900">{payment.supplier}</p>
                      </div>
                      <div>
                        <p className="text-xs text-slate-500">Invoice</p>
                        <p className="text-sm font-medium text-slate-900">{payment.invoiceNumber}</p>
                      </div>
                      <div>
                        <p className="text-xs text-slate-500">Due Date</p>
                        <p className="text-sm font-medium text-slate-900">{payment.dueDate}</p>
                      </div>
                      <div>
                        <p className="text-xs text-slate-500">Bank Reference</p>
                        <p className="text-sm font-medium text-slate-900">{payment.bankVerification.bankReference}</p>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-3">
                      <div className="bg-purple-50 border border-purple-200 rounded-lg p-3">
                        <div className="flex items-start gap-2">
                          <Shield className="text-purple-600 mt-0.5" size={16} />
                          <div className="flex-1">
                            <p className="text-sm font-medium text-purple-900">PP-1: AI Approval Prediction</p>
                            <p className="text-xs text-purple-700 mt-1">{payment.approvalPrediction}</p>
                            <div className="flex items-center gap-2 text-xs text-purple-700 mt-2">
                              <span>Confidence: {payment.approvalConfidence}%</span>
                            </div>
                          </div>
                        </div>
                      </div>

                      <div className="bg-orange-50 border border-orange-200 rounded-lg p-3">
                        <div className="flex items-start gap-2">
                          <Building2 className="text-orange-600 mt-0.5" size={16} />
                          <div className="flex-1">
                            <p className="text-sm font-medium text-orange-900">BV-1: Bank Status Verification</p>
                            <p className="text-xs text-orange-700 mt-1">
                              {payment.bankVerification.verificationStatus === 'verified' ? 'Verified successfully' :
                               payment.bankVerification.verificationStatus === 'verifying' ? 'Verification in progress' :
                               payment.bankVerification.verificationStatus === 'error' ? 'Verification failed' : 'Not yet verified'}
                            </p>
                            <div className="flex items-center gap-2 text-xs text-orange-700 mt-2">
                              <span>Last checked: {payment.bankVerification.lastChecked}</span>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>

                    <div className="bg-blue-50 border border-blue-200 rounded-lg p-3 mt-3">
                      <div className="flex items-start gap-2">
                        <Calendar className="text-blue-600 mt-0.5" size={16} />
                        <div>
                          <p className="text-sm font-medium text-blue-900">PP-2: Auto-Scheduled for {payment.scheduledDate}</p>
                          <p className="text-xs text-blue-700 mt-1">{payment.schedulingReason}</p>
                        </div>
                      </div>
                    </div>

                    {payment.bankVerification.errorMessage && (
                      <div className="bg-red-50 border border-red-200 rounded-lg p-3 mt-3">
                        <div className="flex items-start gap-2">
                          <AlertTriangle className="text-red-600 mt-0.5" size={16} />
                          <div>
                            <p className="text-sm font-medium text-red-900">Bank Error</p>
                            <p className="text-xs text-red-700">{payment.bankVerification.errorMessage}</p>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>

                  <div className="text-right ml-4">
                    <div className="text-2xl font-bold text-slate-900">{payment.amount}</div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Selected Payment Details Modal */}
      {selectedPayment && (
        <div
          className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-8"
          onClick={() => setSelectedPayment(null)}
        >
          <div
            className="bg-white rounded-lg shadow-xl max-w-4xl w-full max-h-[90vh] overflow-auto"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="p-6 border-b border-slate-200">
              <h2 className="text-2xl font-bold text-slate-900">Payment Details: {selectedPayment.id}</h2>
            </div>

            <div className="p-6 space-y-6">
              {/* Payment Info */}
              <div className="bg-slate-50 rounded-lg p-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-xs text-slate-500 mb-1">Supplier</p>
                    <p className="font-medium text-slate-900">{selectedPayment.supplier}</p>
                  </div>
                  <div>
                    <p className="text-xs text-slate-500 mb-1">Invoice Number</p>
                    <p className="font-medium text-slate-900">{selectedPayment.invoiceNumber}</p>
                  </div>
                  <div>
                    <p className="text-xs text-slate-500 mb-1">Amount</p>
                    <p className="text-2xl font-bold text-slate-900">{selectedPayment.amount}</p>
                  </div>
                  <div>
                    <p className="text-xs text-slate-500 mb-1">Due Date</p>
                    <p className="font-medium text-slate-900">{selectedPayment.dueDate}</p>
                  </div>
                </div>
              </div>

              {/* PP-1: Approval Assessment */}
              <div className="bg-purple-50 border border-purple-200 rounded-lg p-4">
                <div className="flex items-start gap-3">
                  <Shield className="text-purple-600 mt-1" size={24} />
                  <div className="flex-1">
                    <h3 className="font-semibold text-purple-900 mb-3">PP-1: AI Approval Assessment</h3>

                    <div className="bg-white rounded-lg p-4 space-y-3">
                      <div>
                        <p className="text-sm font-medium text-slate-900 mb-1">Prediction</p>
                        <p className="text-sm text-slate-700">{selectedPayment.approvalPrediction}</p>
                      </div>

                      <div>
                        <p className="text-sm font-medium text-slate-900 mb-2">AI Confidence Level</p>
                        <div className="flex items-center gap-3">
                          <div className="flex-1 bg-purple-200 rounded-full h-3">
                            <div
                              className="bg-purple-600 h-3 rounded-full"
                              style={{ width: `${selectedPayment.approvalConfidence}%` }}
                            ></div>
                          </div>
                          <span className="font-bold text-purple-900">{selectedPayment.approvalConfidence}%</span>
                        </div>
                      </div>

                      <div className="grid grid-cols-2 gap-4 pt-3 border-t border-slate-200">
                        <div>
                          <p className="text-xs text-slate-500">Approval Required</p>
                          <p className={`text-sm font-bold ${selectedPayment.approvalRequired ? 'text-red-600' : 'text-green-600'}`}>
                            {selectedPayment.approvalRequired ? 'YES' : 'NO'}
                          </p>
                        </div>
                        <div>
                          <p className="text-xs text-slate-500">Risk Level</p>
                          <p className={`text-sm font-bold ${selectedPayment.riskLevel === 'high' ? 'text-red-600' : selectedPayment.riskLevel === 'medium' ? 'text-yellow-600' : 'text-green-600'}`}>
                            {selectedPayment.riskLevel.toUpperCase()}
                          </p>
                        </div>
                      </div>
                    </div>

                    <p className="text-xs text-purple-600 mt-3">
                      AI analyzes amount thresholds, expense categories, budget allocations, historical approval patterns, and risk factors
                    </p>
                  </div>
                </div>
              </div>

              {/* PP-2: Auto Scheduling */}
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                <div className="flex items-start gap-3">
                  <Calendar className="text-blue-600 mt-1" size={24} />
                  <div className="flex-1">
                    <h3 className="font-semibold text-blue-900 mb-3">PP-2: Automated Payment Scheduling</h3>

                    <div className="bg-white rounded-lg p-4 space-y-3">
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <p className="text-xs text-slate-500 mb-1">Scheduled Date</p>
                          <p className="text-lg font-bold text-blue-600">{selectedPayment.scheduledDate}</p>
                        </div>
                        <div>
                          <p className="text-xs text-slate-500 mb-1">Due Date</p>
                          <p className="text-lg font-bold text-slate-900">{selectedPayment.dueDate}</p>
                        </div>
                      </div>

                      <div className="pt-3 border-t border-slate-200">
                        <p className="text-sm font-medium text-slate-900 mb-1">Optimization Strategy</p>
                        <p className="text-sm text-slate-700">{selectedPayment.schedulingReason}</p>
                      </div>

                      <div className="pt-3 border-t border-slate-200">
                        <p className="text-sm font-medium text-slate-900 mb-1">Cash Flow Impact</p>
                        <p className="text-sm text-slate-700">{selectedPayment.cashFlowImpact}</p>
                      </div>
                    </div>

                    <p className="text-xs text-blue-600 mt-3">
                      AI optimizes payment timing considering due dates, early payment discounts, cash flow projections, and bank balance
                    </p>
                  </div>
                </div>
              </div>

              {/* BV-1: Bank Verification */}
              <div className="bg-orange-50 border border-orange-200 rounded-lg p-4">
                <div className="flex items-start gap-3">
                  <Building2 className="text-orange-600 mt-1" size={24} />
                  <div className="flex-1">
                    <h3 className="font-semibold text-orange-900 mb-3">BV-1: Bank Status Verification</h3>

                    <div className="bg-white rounded-lg p-4 space-y-3">
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <p className="text-sm font-medium text-slate-900 mb-1">Bank Status</p>
                          <span className={`inline-flex items-center gap-2 px-3 py-1.5 rounded-full text-sm font-medium ${
                            selectedPayment.bankVerification.bankStatus === 'completed' ? 'bg-green-100 text-green-800' :
                            selectedPayment.bankVerification.bankStatus === 'failed' ? 'bg-red-100 text-red-800' :
                            selectedPayment.bankVerification.bankStatus === 'processing' ? 'bg-blue-100 text-blue-800' :
                            'bg-yellow-100 text-yellow-800'
                          }`}>
                            {selectedPayment.bankVerification.bankStatus === 'completed' && <CheckCircle size={16} />}
                            {selectedPayment.bankVerification.bankStatus === 'failed' && <XCircle size={16} />}
                            {selectedPayment.bankVerification.bankStatus === 'processing' && <RefreshCw size={16} className="animate-spin" />}
                            {selectedPayment.bankVerification.bankStatus === 'pending' && <Clock size={16} />}
                            {selectedPayment.bankVerification.bankStatus.toUpperCase()}
                          </span>
                        </div>
                        <div>
                          <p className="text-sm font-medium text-slate-900 mb-1">Verification Status</p>
                          <span className={`inline-flex items-center gap-2 px-3 py-1.5 rounded-full text-sm font-medium ${
                            selectedPayment.bankVerification.verificationStatus === 'verified' ? 'bg-green-100 text-green-800' :
                            selectedPayment.bankVerification.verificationStatus === 'error' ? 'bg-red-100 text-red-800' :
                            selectedPayment.bankVerification.verificationStatus === 'verifying' ? 'bg-blue-100 text-blue-800' :
                            'bg-slate-100 text-slate-800'
                          }`}>
                            {selectedPayment.bankVerification.verificationStatus === 'verified' && <CheckCircle size={16} />}
                            {selectedPayment.bankVerification.verificationStatus === 'error' && <XCircle size={16} />}
                            {selectedPayment.bankVerification.verificationStatus === 'verifying' && <RefreshCw size={16} className="animate-spin" />}
                            {selectedPayment.bankVerification.verificationStatus === 'not_verified' && <Clock size={16} />}
                            {selectedPayment.bankVerification.verificationStatus.replace('_', ' ').toUpperCase()}
                          </span>
                        </div>
                      </div>

                      <div className="pt-3 border-t border-slate-200">
                        <p className="text-sm font-medium text-slate-900 mb-2">Bank Details</p>
                        <div className="space-y-2">
                          <div className="flex justify-between text-sm">
                            <span className="text-slate-600">Bank Name:</span>
                            <span className="font-medium text-slate-900">{selectedPayment.bankVerification.bankName}</span>
                          </div>
                          <div className="flex justify-between text-sm">
                            <span className="text-slate-600">Account Number:</span>
                            <span className="font-medium text-slate-900">{selectedPayment.bankVerification.accountNumber}</span>
                          </div>
                          <div className="flex justify-between text-sm">
                            <span className="text-slate-600">Transaction Type:</span>
                            <span className="font-medium text-slate-900">{selectedPayment.bankVerification.transactionType}</span>
                          </div>
                          <div className="flex justify-between text-sm">
                            <span className="text-slate-600">Bank Reference:</span>
                            <span className="font-medium text-slate-900">{selectedPayment.bankVerification.bankReference}</span>
                          </div>
                          <div className="flex justify-between text-sm">
                            <span className="text-slate-600">Processing Time:</span>
                            <span className="font-medium text-slate-900">{selectedPayment.bankVerification.processingTime}</span>
                          </div>
                        </div>
                      </div>

                      <div className="pt-3 border-t border-slate-200">
                        <p className="text-sm font-medium text-slate-900 mb-2">Verification Activity</p>
                        <div className="space-y-2">
                          <div className="flex justify-between text-sm">
                            <span className="text-slate-600">Initiated:</span>
                            <span className="font-medium text-slate-900">{selectedPayment.bankVerification.initiatedDate}</span>
                          </div>
                          <div className="flex justify-between text-sm">
                            <span className="text-slate-600">Last Checked:</span>
                            <span className="font-medium text-slate-900">{selectedPayment.bankVerification.lastChecked}</span>
                          </div>
                          <div className="flex justify-between text-sm">
                            <span className="text-slate-600">Verification Attempts:</span>
                            <span className="font-medium text-slate-900">{selectedPayment.bankVerification.retryCount}</span>
                          </div>
                        </div>
                      </div>

                      {selectedPayment.bankVerification.errorMessage && (
                        <div className="pt-3 border-t border-red-200 bg-red-50 -m-4 p-4 mt-3">
                          <div className="flex items-start gap-2">
                            <AlertTriangle className="text-red-600 mt-0.5" size={20} />
                            <div>
                              <p className="text-sm font-medium text-red-900 mb-1">Error Details</p>
                              <p className="text-sm text-red-700">{selectedPayment.bankVerification.errorMessage}</p>
                            </div>
                          </div>
                        </div>
                      )}
                    </div>

                    <p className="text-xs text-orange-600 mt-3">
                      AI continuously monitors bank APIs to confirm payment status in real-time, automatically retrying verification up to 5 times for pending transactions
                    </p>
                  </div>
                </div>
              </div>
            </div>

            <div className="p-6 border-t border-slate-200 flex justify-end gap-3">
              {selectedPayment.status === 'pending_approval' && (
                <>
                  <button className="px-6 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors">
                    Reject
                  </button>
                  <button className="px-6 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors">
                    Approve
                  </button>
                </>
              )}
              {selectedPayment.bankVerification.bankStatus === 'failed' && (
                <button className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
                  Retry Payment
                </button>
              )}
              {selectedPayment.bankVerification.verificationStatus === 'verifying' && (
                <button className="px-6 py-2 bg-orange-600 text-white rounded-lg hover:bg-orange-700 transition-colors flex items-center gap-2">
                  <RefreshCw size={16} className="animate-spin" />
                  Refresh Status
                </button>
              )}
              <button
                onClick={() => setSelectedPayment(null)}
                className="px-6 py-2 bg-slate-900 text-white rounded-lg hover:bg-slate-800 transition-colors"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
