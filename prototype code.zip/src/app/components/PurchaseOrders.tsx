import { useState } from "react";
import { Sparkles, FileCheck, CheckCircle, Clock, AlertCircle, Package } from "lucide-react";

interface PurchaseOrder {
  id: string;
  needIdentified: string;
  supplier: string;
  items: string;
  total: string;
  status: "ai_identified" | "auto_generated" | "awaiting_approval" | "approved" | "goods_received";
  approvalNeeded: boolean;
  approvalPrediction: string;
  confidence: number;
  createdAt: string;
}

export function PurchaseOrders() {
  const [selectedPO, setSelectedPO] = useState<PurchaseOrder | null>(null);
  const [showCreateModal, setShowCreateModal] = useState(false);

  const [newPO, setNewPO] = useState({
    supplier: "",
    items: "",
    total: "",
  });

  const [sortBy, setSortBy] = useState<"newest" | "oldest" | "amount_high" | "amount_low">("newest");

  const purchaseOrders: PurchaseOrder[] = [
    {
      id: "PO-0315",
      needIdentified: "Low inventory alert: Office supplies running low",
      supplier: "Office Depot Inc.",
      items: "Paper reams (50), Printer ink (12), Pens (100)",
      total: "$1,245.00",
      status: "goods_received",
      approvalNeeded: false,
      approvalPrediction: "No approval needed (standard supplies, under $5K threshold)",
      confidence: 98,
      createdAt: "2026-04-20 09:15"
    },
    {
      id: "PO-0316",
      needIdentified: "IT Department request: New development laptops",
      supplier: "Dell Technologies",
      items: "Dell XPS 15 (5 units), USB-C Docks (5 units)",
      total: "$12,500.00",
      status: "awaiting_approval",
      approvalNeeded: true,
      approvalPrediction: "Approval required (high value, IT equipment)",
      confidence: 95,
      createdAt: "2026-04-21 14:30"
    },
    {
      id: "PO-0317",
      needIdentified: "AI detected: Recurring maintenance supplies due",
      supplier: "Industrial Supply Co.",
      items: "Cleaning supplies, Safety equipment, Maintenance tools",
      total: "$3,850.00",
      status: "approved",
      approvalNeeded: false,
      approvalPrediction: "No approval needed (recurring order, pre-approved category)",
      confidence: 99,
      createdAt: "2026-04-21 16:45"
    },
    {
      id: "PO-0318",
      needIdentified: "Marketing budget utilization: Event materials needed",
      supplier: "PrintPro Solutions",
      items: "Banners (10), Brochures (5000), Business cards (2000)",
      total: "$2,100.00",
      status: "auto_generated",
      approvalNeeded: false,
      approvalPrediction: "No approval needed (within marketing budget allocation)",
      confidence: 92,
      createdAt: "2026-04-22 08:20"
    },
    {
      id: "PO-0319",
      needIdentified: "AI pattern detection: Quarterly software license renewal",
      supplier: "Microsoft Corporation",
      items: "Office 365 licenses (50 users, annual)",
      total: "$7,500.00",
      status: "ai_identified",
      approvalNeeded: true,
      approvalPrediction: "Approval likely needed (software licensing, high value)",
      confidence: 88,
      createdAt: "2026-04-22 10:05"
    }
  ];

  const [poList, setPoList] = useState<PurchaseOrder[]>(purchaseOrders);

  const getStatusBadge = (status: PurchaseOrder["status"]) => {
    const badges = {
      ai_identified: { label: "AI Identified", color: "bg-purple-100 text-purple-800" },
      auto_generated: { label: "Auto Generated", color: "bg-blue-100 text-blue-800" },
      awaiting_approval: { label: "Awaiting Approval", color: "bg-orange-100 text-orange-800" },
      approved: { label: "Approved", color: "bg-green-100 text-green-800" },
      goods_received: { label: "Goods Received", color: "bg-slate-100 text-slate-800" }
    };
    return badges[status];
  };

  const sortedPOs = [...poList].sort((a, b) => {
    if (sortBy === "newest") {
      return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
    }
    if (sortBy === "oldest") {
      return new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime();
    }
    if (sortBy === "amount_high") {
      return parseFloat(b.total.replace(/[^0-9.-]+/g, "")) - parseFloat(a.total.replace(/[^0-9.-]+/g, ""));
    }
    if (sortBy === "amount_low") {
      return parseFloat(a.total.replace(/[^0-9.-]+/g, "")) - parseFloat(b.total.replace(/[^0-9.-]+/g, ""));
    }
    return 0;
  });

  return (
    <div className="p-8">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-slate-900">Purchase Orders</h1>
        <p className="text-slate-600 mt-2">AI-powered purchase need identification and automated PO generation</p>
      </div>

      {/* Purchase Orders List */}
      <div className="bg-white rounded-lg shadow">
        <div className="p-6 border-b border-slate-200 flex items-center justify-between">
          <h2 className="text-xl font-bold text-slate-900">Purchase Orders</h2>

          <select
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value as any)}
            className="border rounded-lg px-3 py-2 text-sm"
          >
            <option value="newest">Newest First</option>
            <option value="oldest">Oldest First</option>
            <option value="amount_high">Amount: High → Low</option>
            <option value="amount_low">Amount: Low → High</option>
          </select>
        </div>
        
        <div className="divide-y divide-slate-200">
          {sortedPOs.map((po) => { 
            const statusBadge = getStatusBadge(po.status);
            return (
              <div
                key={po.id}
                className="p-6 hover:bg-slate-50 cursor-pointer transition-colors"
                onClick={() => setSelectedPO(po)}
              >
                <div className="flex items-start justify-between mb-3">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-2">
                      <h3 className="font-bold text-slate-900">{po.id}</h3>
                      <span className={`px-3 py-1 rounded-full text-xs font-medium ${statusBadge.color}`}>
                        {statusBadge.label}
                      </span>
                      {po.approvalNeeded && (
                        <span className="px-3 py-1 rounded-full text-xs font-medium bg-red-100 text-red-800">
                          Approval Required
                        </span>
                      )}
                    </div>

                    <div className="flex items-start gap-2 mb-2">
                      <Sparkles className="text-purple-600 mt-1" size={16} />
                      <p className="text-sm text-slate-700">
                        <span className="font-medium">AI Identified:</span> {po.needIdentified}
                      </p>
                    </div>

                    <div className="grid grid-cols-2 gap-4 mt-3">
                      <div>
                        <p className="text-xs text-slate-500">Supplier</p>
                        <p className="text-sm font-medium text-slate-900">{po.supplier}</p>
                      </div>
                      <div>
                        <p className="text-xs text-slate-500">Items</p>
                        <p className="text-sm font-medium text-slate-900">{po.items}</p>
                      </div>
                    </div>
                  </div>

                  <div className="text-right ml-4">
                    <div className="text-2xl font-bold text-slate-900">{po.total}</div>
                    <div className="text-xs text-slate-500 mt-1">{po.createdAt}</div>
                  </div>
                </div>

                <div className="bg-blue-50 border border-blue-200 rounded-lg p-3 mt-3">
                  <div className="flex items-start gap-2">
                    <AlertCircle className="text-blue-600 mt-0.5" size={16} />
                    <div className="flex-1">
                      <p className="text-sm font-medium text-blue-900">AI Approval Prediction</p>
                      <p className="text-sm text-blue-700">{po.approvalPrediction}</p>
                      <div className="mt-2">
                        <div className="flex items-center justify-between text-xs text-blue-700 mb-1">
                          <span>Confidence</span>
                          <span className="font-medium">{po.confidence}%</span>
                        </div>
                        <div className="w-full bg-blue-200 rounded-full h-2">
                          <div
                            className="bg-blue-600 h-2 rounded-full"
                            style={{ width: `${po.confidence}%` }}
                          ></div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Selected PO Details Modal */}
{showCreateModal && (
  <div
    className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50"
    onClick={() => setShowCreateModal(false)}
  >
    <div
      className="bg-white rounded-lg shadow-xl w-full max-w-lg p-6"
      onClick={(e) => e.stopPropagation()}
    >
      <h2 className="text-xl font-bold mb-4">Create Purchase Order</h2>

      <div className="space-y-4">
        <input
          type="text"
          placeholder="Supplier"
          className="w-full border p-2 rounded"
          value={newPO.supplier}
          onChange={(e) => setNewPO({ ...newPO, supplier: e.target.value })}
        />

        <input
          type="text"
          placeholder="Items"
          className="w-full border p-2 rounded"
          value={newPO.items}
          onChange={(e) => setNewPO({ ...newPO, items: e.target.value })}
        />

        <input
          type="text"
          placeholder="Total Amount"
          className="w-full border p-2 rounded"
          value={newPO.total}
          onChange={(e) => setNewPO({ ...newPO, total: e.target.value })}
        />
      </div>

      <div className="flex justify-end gap-3 mt-6">
        <button
          onClick={() => setShowCreateModal(false)}
          className="px-4 py-2 bg-gray-200 rounded"
        >
          Cancel
        </button>
        
        <button
          onClick={() => {
            const newEntry: PurchaseOrder = {
              id: `PO-${Math.floor(Math.random() * 10000)}`,
              needIdentified: "Manually created purchase order",
              supplier: newPO.supplier,
              items: newPO.items,
              total: newPO.total,
              status: "auto_generated",
              approvalNeeded: true,
              approvalPrediction: "Pending AI evaluation",
              confidence: 0,
              createdAt: new Date().toISOString().slice(0, 16).replace("T", " "),
            };

            setPoList([newEntry, ...poList]);
            setShowCreateModal(false);
            setNewPO({ supplier: "", items: "", total: "" });
          }}
          className="px-4 py-2 bg-blue-600 text-white rounded"
        >
          Create
        </button>
      </div>
    </div>
  </div>
)}
      
      {selectedPO && (
        <div
          className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-8"
          onClick={() => setSelectedPO(null)}
        >
          <div
            className="bg-white rounded-lg shadow-xl max-w-2xl w-full max-h-[90vh] overflow-auto"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="p-6 border-b border-slate-200">
              <h2 className="text-2xl font-bold text-slate-900">{selectedPO.id} Details</h2>
            </div>

            <div className="p-6 space-y-6">
              <div className="bg-purple-50 border border-purple-200 rounded-lg p-4">
                <div className="flex items-start gap-3">
                  <Sparkles className="text-purple-600 mt-1" size={24} />
                  <div>
                    <h3 className="font-semibold text-purple-900 mb-1">PO-1: AI Need Identification</h3>
                    <p className="text-sm text-purple-800">{selectedPO.needIdentified}</p>
                    <p className="text-xs text-purple-600 mt-2">Detected via inventory monitoring, usage patterns, and predictive analytics</p>
                  </div>
                </div>
              </div>

              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                <div className="flex items-start gap-3">
                  <FileCheck className="text-blue-600 mt-1" size={24} />
                  <div className="flex-1">
                    <h3 className="font-semibold text-blue-900 mb-1">PO-2: Auto-Generated Purchase Order</h3>
                    <div className="space-y-2 mt-3">
                      <div className="flex justify-between text-sm">
                        <span className="text-blue-700">Supplier:</span>
                        <span className="font-medium text-blue-900">{selectedPO.supplier}</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-blue-700">Items:</span>
                        <span className="font-medium text-blue-900">{selectedPO.items}</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-blue-700">Total Amount:</span>
                        <span className="font-medium text-blue-900">{selectedPO.total}</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-blue-700">Created:</span>
                        <span className="font-medium text-blue-900">{selectedPO.createdAt}</span>
                      </div>
                    </div>
                    <p className="text-xs text-blue-600 mt-3">Complete order details generated with supplier info, pricing, and delivery terms</p>
                  </div>
                </div>
              </div>

              <div className="bg-orange-50 border border-orange-200 rounded-lg p-4">
                <div className="flex items-start gap-3">
                  <AlertCircle className="text-orange-600 mt-1" size={24} />
                  <div className="flex-1">
                    <h3 className="font-semibold text-orange-900 mb-1">PO-3: Approval Prediction</h3>
                    <p className="text-sm text-orange-800 mb-3">{selectedPO.approvalPrediction}</p>
                    <div className="flex items-center justify-between text-sm mb-2">
                      <span className="text-orange-700">AI Confidence:</span>
                      <span className="font-bold text-orange-900">{selectedPO.confidence}%</span>
                    </div>
                    <div className="w-full bg-orange-200 rounded-full h-3">
                      <div
                        className="bg-orange-600 h-3 rounded-full"
                        style={{ width: `${selectedPO.confidence}%` }}
                      ></div>
                    </div>
                    <p className="text-xs text-orange-600 mt-3">Prediction based on amount, category, budget allocation, and approval history</p>
                  </div>
                </div>
              </div>

              {selectedPO.status === "goods_received" && (
                <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                  <div className="flex items-start gap-3">
                    <Package className="text-green-600 mt-1" size={24} />
                    <div>
                      <h3 className="font-semibold text-green-900 mb-1">PO-4: Goods Receipt Confirmed</h3>
                      <p className="text-sm text-green-800">AI automatically confirmed receipt of goods</p>
                      <div className="mt-3 space-y-1 text-xs text-green-700">
                        <div className="flex items-center gap-2">
                          <CheckCircle size={14} />
                          <span>Delivery scan verified via warehouse system</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <CheckCircle size={14} />
                          <span>Quantity and quality checks passed</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <CheckCircle size={14} />
                          <span>Invoice and payment processes initiated</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>

            <div className="p-6 border-t border-slate-200 flex justify-end">
              <button
                onClick={() => setSelectedPO(null)}
                className="px-6 py-2 bg-slate-900 text-white rounded-lg hover:bg-slate-800 transition-colors"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}