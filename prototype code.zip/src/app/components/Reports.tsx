import { useState } from "react";
import { FileText, Download } from "lucide-react";

type ReportPeriod = "monthly" | "quarterly" | "yearly";

interface SupplierReport {
  supplier: string;
  totalOrdered: number;
  totalInvoiced: number;
  totalPaid: number;
  outstandingBalance: number;
  transactions: {
    date: string;
    type: string;
    reference: string;
    amount: number;
    status: string;
  }[];
}

export function Reports() {
  const [period, setPeriod] = useState<ReportPeriod>("monthly");
  const [selectedSupplier, setSelectedSupplier] = useState<string | null>(null);

  // Embedded data matching the structure from other components
  const purchaseOrders = [
    { id: "PO-0315", supplier: "Office Depot Inc.", amount: 1245.00, created_at: "2026-04-20", goods_received: true },
    { id: "PO-0316", supplier: "Dell Technologies", amount: 12500.00, created_at: "2026-04-21", goods_received: false },
    { id: "PO-0317", supplier: "Industrial Supply Co.", amount: 3850.00, created_at: "2026-04-21", goods_received: true }
  ];

  const invoices = [
    { id: "INV-001", supplier: "Office Depot Inc.", invoice_number: "OD-2024-4521", extracted_amount: 1245.00, extracted_date: "2026-04-18", matched: true },
    { id: "INV-002", supplier: "Dell Technologies", invoice_number: "DELL-INV-9845", extracted_amount: 12475.00, extracted_date: "2026-04-20", matched: true },
    { id: "INV-003", supplier: "Industrial Supply Co.", invoice_number: "ISC-78921", extracted_amount: 3850.00, extracted_date: "2026-04-19", matched: true }
  ];

  const payments = [
    { id: "PAY-001", supplier: "Office Depot Inc.", invoice_id: "INV-001", amount: 1245.00, scheduled_date: "2026-05-15", status: "completed" as const },
    { id: "PAY-002", supplier: "Dell Technologies", invoice_id: "INV-002", amount: 12475.00, scheduled_date: "2026-05-18", status: "pending" as const },
    { id: "PAY-003", supplier: "Industrial Supply Co.", invoice_id: "INV-003", amount: 3850.00, scheduled_date: "2026-05-17", status: "completed" as const }
  ];

  const generateSupplierReports = (): SupplierReport[] => {
    const supplierMap = new Map<string, SupplierReport>();

    // Process Purchase Orders
    purchaseOrders.forEach((po) => {
      if (!supplierMap.has(po.supplier)) {
        supplierMap.set(po.supplier, {
          supplier: po.supplier,
          totalOrdered: 0,
          totalInvoiced: 0,
          totalPaid: 0,
          outstandingBalance: 0,
          transactions: []
        });
      }

      const report = supplierMap.get(po.supplier)!;
      report.totalOrdered += po.amount;
      report.transactions.push({
        date: po.created_at,
        type: "Purchase Order",
        reference: po.id,
        amount: po.amount,
        status: po.goods_received ? "Goods Received" : "Pending"
      });
    });

    // Process Invoices
    invoices.forEach((inv) => {
      if (!supplierMap.has(inv.supplier)) {
        supplierMap.set(inv.supplier, {
          supplier: inv.supplier,
          totalOrdered: 0,
          totalInvoiced: 0,
          totalPaid: 0,
          outstandingBalance: 0,
          transactions: []
        });
      }

      const report = supplierMap.get(inv.supplier)!;
      report.totalInvoiced += inv.extracted_amount;
      report.transactions.push({
        date: inv.extracted_date,
        type: "Invoice",
        reference: inv.invoice_number,
        amount: inv.extracted_amount,
        status: inv.matched ? "Matched" : "Unmatched"
      });
    });

    // Process Payments
    payments.forEach((pay) => {
      if (!supplierMap.has(pay.supplier)) {
        supplierMap.set(pay.supplier, {
          supplier: pay.supplier,
          totalOrdered: 0,
          totalInvoiced: 0,
          totalPaid: 0,
          outstandingBalance: 0,
          transactions: []
        });
      }

      const report = supplierMap.get(pay.supplier)!;

      // Only count as paid if status is completed
      if (pay.status === "completed") {
        report.totalPaid += pay.amount;
      }

      report.transactions.push({
        date: pay.scheduled_date,
        type: "Payment",
        reference: pay.id,
        amount: pay.amount,
        status: pay.status === "completed" ? "Paid" : pay.status === "scheduled" ? "Scheduled" : "Pending"
      });
    });

    // Calculate outstanding balance
    supplierMap.forEach((report) => {
      report.outstandingBalance = report.totalInvoiced - report.totalPaid;
      // Sort transactions by date
      report.transactions.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
    });

    return Array.from(supplierMap.values()).sort((a, b) =>
      b.outstandingBalance - a.outstandingBalance
    );
  };

  const reports = generateSupplierReports();
  const selectedReport = reports.find(r => r.supplier === selectedSupplier);

  const getPeriodLabel = () => {
    const now = new Date();
    const month = now.toLocaleString('default', { month: 'long', year: 'numeric' });
    const quarter = `Q${Math.floor(now.getMonth() / 3) + 1} ${now.getFullYear()}`;
    const year = now.getFullYear().toString();

    return period === "monthly" ? month : period === "quarterly" ? quarter : year;
  };

  const exportReport = () => {
    const reportData = reports.map(r => ({
      Supplier: r.supplier,
      "Total Ordered": `$${r.totalOrdered.toFixed(2)}`,
      "Total Invoiced": `$${r.totalInvoiced.toFixed(2)}`,
      "Total Paid": `$${r.totalPaid.toFixed(2)}`,
      "Outstanding Balance": `$${r.outstandingBalance.toFixed(2)}`
    }));

    console.log("Exporting report:", reportData);
    alert("Report export functionality - Data logged to console");
  };

  return (
    <div className="p-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-slate-900">Supplier Reports</h1>
        <p className="text-slate-600 mt-2">Outstanding balances and transaction history by supplier</p>
      </div>

      {/* Period Selector and Export */}
      <div className="bg-white rounded-lg shadow p-6 mb-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <label className="font-medium text-slate-900">Report Period:</label>
            <div className="flex gap-2">
              <button
                onClick={() => setPeriod("monthly")}
                className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                  period === "monthly"
                    ? "bg-blue-600 text-white"
                    : "bg-slate-100 text-slate-700 hover:bg-slate-200"
                }`}
              >
                Monthly
              </button>
              <button
                onClick={() => setPeriod("quarterly")}
                className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                  period === "quarterly"
                    ? "bg-blue-600 text-white"
                    : "bg-slate-100 text-slate-700 hover:bg-slate-200"
                }`}
              >
                Quarterly
              </button>
              <button
                onClick={() => setPeriod("yearly")}
                className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                  period === "yearly"
                    ? "bg-blue-600 text-white"
                    : "bg-slate-100 text-slate-700 hover:bg-slate-200"
                }`}
              >
                Yearly
              </button>
            </div>
            <div className="text-sm text-slate-600 ml-4">
              Period: <span className="font-medium text-slate-900">{getPeriodLabel()}</span>
            </div>
          </div>

          <button
            onClick={exportReport}
            className="flex items-center gap-2 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors"
          >
            <Download size={16} />
            Export Report
          </button>
        </div>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
        <div className="bg-white rounded-lg shadow p-4">
          <div className="text-sm text-slate-600 mb-1">Total Suppliers</div>
          <div className="text-2xl font-bold text-slate-900">{reports.length}</div>
        </div>
        <div className="bg-white rounded-lg shadow p-4">
          <div className="text-sm text-slate-600 mb-1">Total Ordered</div>
          <div className="text-2xl font-bold text-blue-600">
            ${reports.reduce((sum, r) => sum + r.totalOrdered, 0).toFixed(2)}
          </div>
        </div>
        <div className="bg-white rounded-lg shadow p-4">
          <div className="text-sm text-slate-600 mb-1">Total Paid</div>
          <div className="text-2xl font-bold text-green-600">
            ${reports.reduce((sum, r) => sum + r.totalPaid, 0).toFixed(2)}
          </div>
        </div>
        <div className="bg-white rounded-lg shadow p-4">
          <div className="text-sm text-slate-600 mb-1">Outstanding Balance</div>
          <div className="text-2xl font-bold text-red-600">
            ${reports.reduce((sum, r) => sum + r.outstandingBalance, 0).toFixed(2)}
          </div>
        </div>
      </div>

      {/* Supplier Reports Table */}
      <div className="bg-white rounded-lg shadow overflow-hidden">
        <div className="p-6 border-b border-slate-200">
          <h2 className="text-xl font-bold text-slate-900">Supplier Outstanding Balances</h2>
        </div>

        <table className="w-full">
          <thead className="bg-slate-50 border-b border-slate-200">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase">Supplier</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase">Total Ordered</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase">Total Invoiced</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase">Total Paid</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase">Outstanding Balance</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-200">
            {reports.map((report) => (
              <tr key={report.supplier} className="hover:bg-slate-50">
                <td className="px-6 py-4 text-sm font-medium text-slate-900">{report.supplier}</td>
                <td className="px-6 py-4 text-sm text-slate-700">${report.totalOrdered.toFixed(2)}</td>
                <td className="px-6 py-4 text-sm text-slate-700">${report.totalInvoiced.toFixed(2)}</td>
                <td className="px-6 py-4 text-sm text-green-700 font-medium">${report.totalPaid.toFixed(2)}</td>
                <td className="px-6 py-4 text-sm font-bold">
                  <span className={report.outstandingBalance > 0 ? "text-red-600" : "text-green-600"}>
                    ${report.outstandingBalance.toFixed(2)}
                  </span>
                </td>
                <td className="px-6 py-4">
                  <button
                    onClick={() => setSelectedSupplier(report.supplier)}
                    className="flex items-center gap-1 text-sm text-blue-600 hover:text-blue-800"
                  >
                    <FileText size={14} />
                    View Details
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Supplier Detail Modal */}
      {selectedReport && (
        <div
          className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-8"
          onClick={() => setSelectedSupplier(null)}
        >
          <div
            className="bg-white rounded-lg shadow-xl max-w-4xl w-full max-h-[90vh] overflow-auto"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="p-6 border-b border-slate-200">
              <h2 className="text-2xl font-bold text-slate-900">{selectedReport.supplier}</h2>
              <p className="text-sm text-slate-600 mt-1">Transaction History - {getPeriodLabel()}</p>
            </div>

            <div className="p-6">
              {/* Summary */}
              <div className="grid grid-cols-4 gap-4 mb-6">
                <div className="bg-slate-50 rounded-lg p-4">
                  <div className="text-xs text-slate-600 mb-1">Total Ordered</div>
                  <div className="text-lg font-bold text-slate-900">${selectedReport.totalOrdered.toFixed(2)}</div>
                </div>
                <div className="bg-slate-50 rounded-lg p-4">
                  <div className="text-xs text-slate-600 mb-1">Total Invoiced</div>
                  <div className="text-lg font-bold text-slate-900">${selectedReport.totalInvoiced.toFixed(2)}</div>
                </div>
                <div className="bg-green-50 rounded-lg p-4">
                  <div className="text-xs text-green-700 mb-1">Total Paid</div>
                  <div className="text-lg font-bold text-green-600">${selectedReport.totalPaid.toFixed(2)}</div>
                </div>
                <div className="bg-red-50 rounded-lg p-4">
                  <div className="text-xs text-red-700 mb-1">Outstanding</div>
                  <div className="text-lg font-bold text-red-600">${selectedReport.outstandingBalance.toFixed(2)}</div>
                </div>
              </div>

              {/* Transactions */}
              <h3 className="font-semibold text-slate-900 mb-3">All Transactions</h3>
              <div className="border border-slate-200 rounded-lg overflow-hidden">
                <table className="w-full">
                  <thead className="bg-slate-50">
                    <tr>
                      <th className="px-4 py-2 text-left text-xs font-medium text-slate-500">Date</th>
                      <th className="px-4 py-2 text-left text-xs font-medium text-slate-500">Type</th>
                      <th className="px-4 py-2 text-left text-xs font-medium text-slate-500">Reference</th>
                      <th className="px-4 py-2 text-left text-xs font-medium text-slate-500">Amount</th>
                      <th className="px-4 py-2 text-left text-xs font-medium text-slate-500">Status</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-200">
                    {selectedReport.transactions.map((txn, idx) => (
                      <tr key={idx} className="hover:bg-slate-50">
                        <td className="px-4 py-2 text-sm text-slate-700">{txn.date}</td>
                        <td className="px-4 py-2 text-sm text-slate-700">{txn.type}</td>
                        <td className="px-4 py-2 text-sm font-medium text-slate-900">{txn.reference}</td>
                        <td className="px-4 py-2 text-sm font-medium text-slate-900">${txn.amount.toFixed(2)}</td>
                        <td className="px-4 py-2">
                          <span className={`inline-block px-2 py-1 text-xs rounded ${
                            txn.status === "Paid" ? "bg-green-100 text-green-800" :
                            txn.status === "Scheduled" ? "bg-blue-100 text-blue-800" :
                            "bg-yellow-100 text-yellow-800"
                          }`}>
                            {txn.status}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            <div className="p-6 border-t border-slate-200 flex justify-end">
              <button
                onClick={() => setSelectedSupplier(null)}
                className="px-6 py-2 bg-slate-900 text-white rounded-lg hover:bg-slate-800 transition-colors"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
