import { Outlet, Link, useLocation } from "react-router";
import { Home, ShoppingCart, FileText, CreditCard, Building2, BookOpen, BarChart3 } from "lucide-react";

export function Root() {
  const location = useLocation();

  const navItems = [
    { path: "/", label: "Dashboard", icon: Home },
    { path: "/purchase-orders", label: "Purchase Orders", icon: ShoppingCart },
    { path: "/invoices", label: "Invoices", icon: FileText },
    { path: "/payments", label: "Payments & Bank", icon: CreditCard },
    { path: "/accounting", label: "Accounting", icon: BookOpen },
    { path: "/reports", label: "Supplier Reports", icon: BarChart3 },
  ];

  return (
    <div className="flex h-full bg-slate-50">
      {/* Sidebar */}
      <aside className="w-64 bg-slate-900 text-white flex flex-col">
        <div className="p-6 border-b border-slate-700">
          <h1 className="text-xl font-bold">AP AI System</h1>
          <p className="text-xs text-slate-400 mt-1">Accounts Payable Automation</p>
        </div>

        <nav className="flex-1 p-4">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = location.pathname === item.path;

            return (
              <Link
                key={item.path}
                to={item.path}
                className={`flex items-center gap-3 px-4 py-3 rounded-lg mb-2 transition-colors ${
                  isActive
                    ? "bg-blue-600 text-white"
                    : "text-slate-300 hover:bg-slate-800"
                }`}
              >
                <Icon size={20} />
                <span className="text-sm">{item.label}</span>
              </Link>
            );
          })}
        </nav>

        <div className="p-4 border-t border-slate-700">
          <div className="flex items-center gap-3 px-4 py-3">
            <div className="w-8 h-8 rounded-full bg-blue-600 flex items-center justify-center">
              <span className="text-xs font-bold">AI</span>
            </div>
            <div>
              <p className="text-sm font-medium">AI Engine Active</p>
              <p className="text-xs text-slate-400">Last sync: 2 min ago</p>
            </div>
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 overflow-auto">
        <Outlet />
      </main>
    </div>
  );
}
