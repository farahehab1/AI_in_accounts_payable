import { createBrowserRouter } from "react-router";
import { Root } from "./components/Root";
import { Dashboard } from "./components/Dashboard";
import { PurchaseOrders } from "./components/PurchaseOrders";
import { InvoiceHandling } from "./components/InvoiceHandling";
import { PaymentProcessing } from "./components/PaymentProcessing";
import { AccountingRecords } from "./components/AccountingRecords";
import { Reports } from "./components/Reports";

export const router = createBrowserRouter([
  {
    path: "/",
    Component: Root,
    children: [
      { index: true, Component: Dashboard },
      { path: "purchase-orders", Component: PurchaseOrders },
      { path: "invoices", Component: InvoiceHandling },
      { path: "payments", Component: PaymentProcessing },
      { path: "accounting", Component: AccountingRecords },
      { path: "reports", Component: Reports },
    ],
  },
]);
